LocalTerm 1.5.6 — macOS / Apple Silicon
=====================================

HELYI SSH-KLIENS, HORDOZHATÓ TITKOSÍTOTT VAULTTAL

A LocalTerm a hostokat, jelszavakat, privát kulcsokat, kulcsjelszavakat,
snippeteket és porttovábbítási szabályokat egy általad választott
.ltvault fájlban tárolja. Nincs szükség LocalTerm-fiókra.

1. TELEPÍTÉS ÉS FRISSÍTÉS

A LocalTerm-1.5.6-Mac-AppleSilicon.zip Apple Silicon (M-sorozatú) Macre
készült. Intel Macre külön build szükséges.

- Bontsd ki a ZIP-et, majd húzd a LocalTerm.app fájlt az Applications /
  Alkalmazások mappába. Node.js vagy Electron külön telepítése nem kell.
- Frissítés előtt lépj ki a régi LocalTermből, majd cseréld az alkalmazást.
- A vault külön fájl, így az app cseréje nem helyettesíti és nem migrálja
  automatikusan a vaultot. A meglévő vaultod használható az új kiadással.
- A build nincs digitálisan aláírva és nincs notarizálva. A macOS emiatt
  blokkolhatja az első indítást. A saját, megbízható példány megnyitásáról
  az Apple útmutatója ír:
  https://support.apple.com/en-gb/102445

2. VAULT LÉTREHOZÁSA VAGY MEGNYITÁSA

Új vault: Create a new vault → legalább 12 karakteres jelszó és megerősítés
→ Choose location & create → válassz új fájlt egy írható mappában.

Meglévő vault: Choose a vault file… → válaszd a .ltvault fájlt → add meg
a jelszavát → Unlock vault. Újraindítás után újra válaszd ki a fájlt.

A fájl lehet helyi lemezen, külső meghajtón vagy saját szinkronizált
mappádban. Ne felejtsd el a jelszót: nincs helyreállítási szolgáltatás.
A Macen és Windowson készült LocalTerm-vault formátuma megegyezik.

3. HOSTOK, KULCSOK, TERMINÁLOK

- Keys → New key: illeszd be vagy importáld a privát kulcsot, és szükség
  esetén add meg a kulcs saját jelszavát. Az import a kulcs tartalmát a
  vaultba másolja; az eredeti kulcsfájlt nem módosítja vagy törli.
- Hosts → New host: név, szervercím, felhasználónév, port, jelszó vagy
  privát kulcs. A Group mezővel csoportosíthatsz.
- Save changes után a bejegyzés a titkosított vaultfájlba mentődik.
- Connect: az első kapcsolatnál ellenőrizd a szerver SSH-ujjlenyomatát
  megbízható forrásból. Megváltozott ujjlenyomatnál az app blokkolja a
  kapcsolatot. Igazolt kulcscsere után a host szerkesztőjében a Forget
  saved SSH fingerprint… gombbal törölhető a régi érték.
- A kompakt hostkártyák feletti keresővel szűrhetsz.

4. ÚJ FÜL, KERESÉS ÉS OSZTOTT NÉZET

- Cmd+T vagy a fülsáv + gombja: új fül kereshető hostválasztóval.
- A kereső név, cím, felhasználónév és csoport alapján szűr.
- Enter: csatlakozás az első találathoz; kattintással is választhatsz.
- Cmd+R: visszatérés az utoljára kijelölt terminálhoz a Workspace-ből.
  A Return to session gomb felül, a fejlécben is elérhető, görgetés nélkül.
  A gyorsbillentyű megtartja az osztott elrendezést és nem tölti újra az appot.
- Cmd+K: kereső fókuszálása az új fülön. Escape: új fül bezárása.
- A korábbi SSH-munkamenetek a hostválasztó megnyitásakor nyitva maradnak.
- Terminál megnyitásakor az oldalsáv eltűnik; a Workspace visszahozza.
- Layout → Single terminal / 2 columns / 3 columns: egyenlő oszlopok.
- Húzd a terminálfület vagy a panel ⠿ fogantyúját a célpanelre.
  Bal/jobb/felső/alsó szélre ejtve osztás, középre ejtve áthelyezés vagy
  csere történik. A zöld kiemelés mutatja a célt. Escape megszakítja.
- Vegyes vízszintes/függőleges elrendezésben legfeljebb hat terminál
  jeleníthető meg. A panelek külön kezelik a bemenetet és a méretezést.

5. SFTP ÉS SNIPPETEK

Egy csatlakoztatott terminálon a Browse files megnyitja a távoli fájlokat.
Könyvtárat böngészhetsz, fájlt tölthetsz fel és le. A letöltés közönséges
fájlt ment az általad választott helyre; nem kerül a vaultba titkosítva.

A Snippets oldalon parancsokat menthetsz. Futtatás előtt az app megerősítést
kér, majd a parancsot az aktív SSH-terminálra küldi.

6. PORTTOVÁBBÍTÁS

Port forwarding → New forwarding rule → SSH host és típus → címek és
portok → Save changes → Start. Leállítás: Stop.

- Local: ezen a Macen figyel, a célt az SSH-szerver felől éri el.
- Remote: az SSH-szerveren figyel, a célt erről a Macről éri el.
- Dynamic: helyi SOCKS5 CONNECT proxy; a célcímet a proxyt használó
  program választja. A cél névfeloldása az SSH-szerveren történik.

Alapértelmezett figyelési cím: 127.0.0.1. A szervernek engedélyeznie kell
az SSH-továbbítást; a Remote kötést a szerver GatewayPorts szabálya is
befolyásolja. A szabály külön SSH-kapcsolatot használ, terminál nélkül is
indítható. Az app bezárása vagy a vault zárolása leállítja az alagutakat.
Aktív szabály szerkesztése után újra el kell indítani a továbbítást.

7. TITKOSÍTOTT VAULT IMPORTÁLÁSA — ÚJ AZ 1.4-BEN

Nyisd meg és oldd fel a célvaultot. Vault settings → Import from another
encrypted vault… → add meg a FORRÁS vault jelszavát → Choose file & import
→ válaszd a forrás .ltvault fájlt.

- Az import előtt titkosított biztonsági másolat készül a célfájl mellé.
- A forrás hostjai, kulcsai és porttovábbítási szabályai összevonódnak a
  célvaulttal. A meglévő bejegyzések, snippetek és megbízható SSH-
  ujjlenyomatok megmaradnak; az app nem írja felül őket forrásbeli értékkel.
- Azonos forrásazonosítók, kulcsok és egyértelmű hostegyezések esetén
  az import igyekszik elkerülni a duplázást.
- A hiányos vagy nem támogatott beállításokkal importált hostok is
  megmaradnak. Ellenőrizd a megjegyzésüket és a felhasználónevüket.
- A forrásfájl nem módosul. A cél vault jelszava változatlan marad.

Ez LocalTerm-vaultok importálója. A Termius saját titkosított adattárának
közvetlen olvasása nem része a szállított alkalmazásnak; ahhoz külön,
felhasználó által engedélyezett migrációs lépés szükséges.

8. MENTÉS, ZÁROLÁS ÉS BIZTONSÁGI MÁSOLAT

A Save changes gomb azonnal ment a kiválasztott fájlba; gépelés közben
nincs folyamatos űrlapmentés. A szerkesztő csak sikeres mentés után záródik.
A mentés titkosított ideiglenes fájlt ír, fsync-et kér, majd átnevezéssel
lecseréli az előző vaultot. Egy későbbi appösszeomlás a már elmentett
adatokat nem felejti el. Áramkimaradásra és lemezhibára nincs teljes garancia.

Vault settings → Save an encrypted copy as…: külön titkosított másolat.
Ezután továbbra is az eredeti fájl marad aktív. A másolat használatához
nyisd meg azt külön. Régi másolatok jelszavát egy későbbi jelszócsere
nem változtatja meg.

Lock vault: bezárja a kapcsolatokat és kiüríti az adatokat a felületről.
Alapból a képernyő zárolásakor, alvó módban és 15 perc inaktivitás után
is zárol. Ezek most a Vault settingsben módosíthatók. A jelszó nem kerül mentésre.

9. ICLOUD DRIVE ÉS TÖBB GÉP

Az iCloud Drive-ban tárolt vault a helyi fájlpéldányon keresztül nyitható
meg. A mappát tartsd letöltve (Keep Downloaded). Gépcsere előtt várd meg
a szinkronizálást, majd a másik gépen frissen nyisd meg a vaultot.
Egyszerre csak egy gépen szerkeszd. A LocalTerm a már észlelt külső
változásnál megtagadja a felülírást, de nincs többgépes zárolás vagy
automatikus összeolvasztás. Két offline szerkesztés ütközhet.

iCloud-specifikus futásteszt nem készült. Tarts külön biztonsági másolatot.
Apple fájlkezelési útmutató:
https://support.apple.com/en-euro/guide/mac-help/mchl1a02d711/27/mac/27

10. TITKOSÍTÁS ÉS KORLÁTOK

AES-256-GCM; scrypt kulcsszármaztatás (N=65536, r=8, p=1), véletlen
32 bájtos salt, mentésenként új 12 bájtos nonce, 16 bájtos hitelesítési tag.
A formátum és a KDF-paraméterek olvasható fejlécben vannak, az adatok
és a privát kulcsok titkosítottak. Feloldva a memóriában hozzáférhetők.
JavaScript alatt a korábbi memóriamásolatok teljes törlése nem garantálható.

A LocalTerm önálló megvalósítás, nem teljes Termius-másolat. Jelenleg nincs
Mosh, soros kapcsolat, SSH-agent/FIDO2, interaktív MFA, ugróhost-kezelés vagy
csapatos megosztás. Az importált ugróhost/proxy/hardveres hitelesítési
követelmények jelölve maradnak, és a közvetlen SSH-csatlakozás blokkolva van.
Független biztonsági audit nem készült.

A kiadáshoz 55 automatizált teszt tartozik. A macOS-felület korábbi
kiadásain terminálkezelést és natív fájlválasztást is ellenőriztünk.
A vaultimportot macOS alatt tényleges mentéssel is végrehajtottuk.

Új az 1.4.4-ben: osztott nézetben egy terminál bezárásakor az üres panel
megszűnik. Ha egy megjelenített terminál marad, az kitölti a teljes
terminálterületet. A háttérben nyitott fülek megmaradnak.

Workspace-fülek (1.4.4)
Az osztott terminálok közös Workspace-fülre kerülnek. Az új host külön fülön,
teljes méretben nyílik meg. A Workspace-re kattintva visszatér a korábbi osztás.
Új terminál hozzáadásához húzd a különálló fület a Workspace-fül fölé, majd
onnan az egyik panel szélére. Több Workspace is nyitható. Az elrendezések az
aktuális feloldott munkamenet idejére maradnak meg.

Egérhúzás javítása (1.4.4): húzás közben stabil marad a fülsáv. Másik fülre
váltáshoz tartsd fölötte röviden (kb. 0,35 másodpercig) a húzott terminált,
majd engedd el a célpanel szélén. Az elengedés nem vált vissza másik fülre.

Ugróhostok / Jump hosts (1.5.0)
1. Mentsd el az ugróhostot a Hosts listában a saját felhasználónevével és
   jelszavával vagy privát kulcsával.
2. A célhostnál kattints az Edit gombra. A „Jump hosts (in connection order)”
   résznél válaszd ki az ugróhostot; több host is felvehető. Az ↑ gombbal
   módosítható a sorrend, a Remove gombbal törölhető egy lépés.
3. Save changes, majd Connect. Minden köztes host saját beállításai érvényesek;
   ha az ugróhostnak is van ugróhostja, azon keresztül indul a kapcsolat.
A terminál, az SFTP és a Local/Remote/Dynamic port forwarding is ezt az
útvonalat használja. A célhost nevét a köztes SSH-szerver oldja fel. Minden
lépés ujjlenyomatát külön ellenőrzi az app. A körkörös és hiányos útvonalakat
elutasítja; legfeljebb nyolc SSH-host lehet egy láncban, a célhosttal együtt.
A kapcsolati útvonal a többi hostadattal együtt a titkosított vaultba mentődik.
A Termiusból importált ugróhostoknál az Edit ablak felajánlja a megőrzött
hivatkozásokból azonosítható hostokat. Ellenőrizd a sorrendet, majd mentsd el.
A meglévő vault használható. Ugróhostos vault módosításához 1.5.0 vagy újabb
LocalTermet használj. Útvonalban használt host törlése előtt távolítsd el a
rá mutató ugróhost-hivatkozásokat. Aktív tunnel hostadatainak módosítása
leállítja a tunnelt; az új útvonalhoz indítsd újra.

Utolsó vault és ugróhost-kereső (1.5.1)
A LocalTerm megjegyzi az utoljára sikeresen megnyitott vagy létrehozott vault
útvonalát. Következő induláskor az Unlock vault gombbal közvetlenül feloldható;
a fájlválasztót csak akkor kell használni, ha másik fájlt szeretnél megnyitni.
A jelszót minden indításkor be kell írni. Csak a fájlútvonal kerül a számítógép
helyi alkalmazásbeállításaiba; a vault tartalma továbbra is titkosított.
Ha a fájlt áthelyezted, válaszd ki újra a Choose a vault file gombbal.
A Jump hosts választó ABC-sorrendben mutatja a hostokat, és a Search jump hosts
mezőben névre, szervercímre, felhasználónévre vagy csoportra is kereshetsz.
A már kiválasztott ugróhostok kapcsolati sorrendjét a rendezés nem változtatja.

Kilépés és duplikálás (1.5.2)
Ha az SSH-munkamenet lezárul (például exit, Ctrl+D vagy kapcsolatmegszakadás),
a terminálpanel és a füle automatikusan eltűnik. Osztott nézetben a többi panel
kitölti a helyét; az utolsó bezárásakor a hostlista jelenik meg. A háttérben
megszűnő kapcsolat nem visz el a hostlistából vagy a megnyitott hostválasztóból.
Jobb kattintás egy terminál fülén → Duplicate: új, független SSH-kapcsolat nyílik
ugyanahhoz a mentett hosthoz, a jelenlegi hitelesítéssel és ugróhost-útvonallal.
Az eredeti kapcsolat megmarad. Az új kapcsolat külön, teljes méretű fülön nyílik.
Workspace-fülön a legutóbb kijelölt tag duplikálódik. Az adott panel fejlécén is
elérhető ugyanez a menü. A Duplicate nem másolja át a távoli shell folyamatait
vagy munkakönyvtárát; új bejelentkezést indít.

Hostkereső automatikus fókusza (1.5.3)
A Hosts menü megnyitásakor a Search hosts mező automatikusan fókuszt kap,
így kattintás nélkül azonnal gépelhetsz. Vaultfeloldáskor, a terminálból
visszatérve és hostcsoport választásakor is a hostkereső aktív.

Automatikus zárolás beállítása (1.5.4)

Vault settings → Automatic vault locking:
- Enable automatic locking: az összes automatikus zárolás be/ki kapcsolása.
- Lock after inactivity: 1–1440 perc között állítható.
- Külön kapcsoló a képernyőzárhoz és a számítógép alvó módjához.
- Save locking settings: azonnal menti és alkalmazza a beállításokat.

Kikapcsolt főkapcsolónál a képernyő zárolása és az alvó mód sem zárolja
a vaultot. A kézi Lock vault és az alkalmazásból való kilépés továbbra is
zárol. A beállítások a titkosított vaultban vannak, újranyitáskor megmaradnak.
A billentyűzet és az egér használata aktivitásnak számít; a távoli terminál
magától érkező kimenete nem indítja újra az időzítőt.

Terminálvágólap (1.5.5)

Kijelöléskor a szöveg automatikusan a rendszer vágólapjára kerül.
Jobb kattintás a terminálon: beillesztés a kattintott panelbe.
Alapból bekapcsolt. Ki- és bekapcsolás: Vault settings → Terminal clipboard
→ Copy selection and paste on right-click → Save clipboard settings.
A választás a titkosított vaultban megmarad, és a nyitott terminálokra is érvényes.
A fülek Duplicate menüje és a billentyűs másolás/beillesztés megmarad.
A rendszer vágólapját a vault zárolása nem törli.

Hostonkénti témák (1.5.6)

Hosts → Edit → Terminal theme: Default, Ember Dune, Emerald, Paper vagy Custom.
A Default minden hostnál a korábbi LocalTerm-színeket tartja meg.
Custom: háttér, betűszín, kurzor, kijelölés háttere és kijelölt szöveg színe,
színválasztóval és hex mezőkkel, élő előnézettel.
Save changes: mentés a titkosított vaultba; a host nyitott termináljai is frissülnek.
