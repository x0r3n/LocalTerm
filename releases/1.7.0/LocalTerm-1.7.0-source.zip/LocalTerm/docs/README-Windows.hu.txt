LocalTerm 1.5.6 — Windows x64

Két változat készül ugyanabból az alkalmazásból:

1. LocalTerm-1.5.6-Windows-x64-Portable.exe
   Másold egy tetszőleges mappába, és indítsd el. Nem telepítő: indításkor
   kibontja és futtatja az alkalmazást. Nincs szükség Node.js vagy Electron
   külön telepítésére.

2. LocalTerm-1.5.6-Windows-x64.zip
   A teljes ZIP-et bontsd ki egy mappába, majd indítsd a benne levő
   LocalTerm.exe fájlt. A többi fájlt és alkönyvtárat hagyd mellette.

Vidd át a saját .ltvault fájlodat is. A Choose a vault file… gombbal nyisd
meg, és add meg a vault jelszavát. A Macen létrehozott LocalTerm vault
azonos jelszóval olvasható; nincs szükség átalakításra.

Windows gyorsbillentyűk:
- Ctrl+T: új fül kereshető hostválasztóval
- Ctrl+R: visszatérés az utoljára kijelölt terminálhoz; nem ablak-újratöltés
- Ctrl+K: kereső fókuszálása az új fülön
- Escape: hostválasztó bezárása

Új az 1.4-ben: titkosított LocalTerm-vault importálása és összevonása.
Vault settings → Import from another encrypted vault… → a FORRÁS jelszava
→ Choose file & import → forrás .ltvault kiválasztása. A célfájl mellé
előbb titkosított biztonsági másolat készül. A meglévő adatok megmaradnak,
a cél jelszava változatlan. A forrás hostjai, kulcsai és porttovábbítási
szabályai importálhatók. A Termius saját adattárának közvetlen olvasása
külön migrációs lépés, nem a beépített importáló feladata.

Az app jelöli az importált, további beállítást igénylő hostokat. A hiányzó
felhasználónév pótolható a host szerkesztőjében. Ugróhost/proxy/hardveres
hitelesítés nincs megvalósítva; az ilyen követelményű hostok közvetlen
SSH-csatlakozása blokkolva van.

A többi alapfunkció megegyezik a macOS 1.4 kiadáséval: osztott, egérrel
rendezhető terminálok; kereshető új fül; SSH, SFTP, snippetek; Local,
Remote és Dynamic SOCKS5 porttovábbítás; AES-256-GCM/scrypt vault.

Ez Intel/AMD 64 bites Windowsra készült build. Windows ARMra nincs külön
natív csomag ebben a kiadásban.

A csomag macOS-en készült electron-builderrel és a Windows x64 Electron
futtatókörnyezettel. A 55 automatizált teszt macOS-en sikeres, az opcionális
natív SSH-gyorsító modulok tiltásával is. A Windows-csomag csak a
platformfüggetlen SSH-megvalósítást tartalmazza. Az elkészült PE/ZIP/ASAR
fájlokat statikusan ellenőriztük; az alkalmazás futása, a fájljogosultságok,
a Windows zárolási eseményei és a hálózati funkciók Windows alatti
ellenőrzése még hátravan.

A kiadás nincs digitálisan aláírva; a Windows biztonsági figyelmeztetést
jeleníthet meg. Ne felejtsd el a vault jelszavát: nincs helyreállítási kulcs
vagy szolgáltatás. Készíts biztonsági másolatot, és ugyanazt a vaultfájlt
ne szerkeszd egyszerre két számítógépen.

A Return to session gomb a Workspace felső fejlécében is elérhető, így
nem szükséges a hosszú hostlista aljára görgetni.

Új az 1.4.4-ben: osztott nézetben egy terminál bezárásakor az üres panel
megszűnik. Ha egy megjelenített terminál marad, az kitölti a teljes
terminálterületet. A háttérben nyitott fülek megmaradnak.

Workspace-fülek (1.4.4)
Az osztott terminálok közös Workspace-fülre kerülnek. Az új host külön fülön,
teljes méretben nyílik meg. A Workspace-re kattintva visszatér a korábbi osztás.
Új terminál hozzáadásához húzd a különálló fület a Workspace-fül fölé, majd
onnan az egyik panel szélére. Több Workspace is nyitható. Az elrendezések az
aktuális feloldott munkamenet idejére maradnak meg.

Egérhúzás javítása (1.4.4): húzás közben stabil marad a fülsáv. Másik fülre
váltáshoz tartsd fölötte röviden (kb. 0,35 másodpercig) a húzott terminált,
majd engedd el a célpanel szélén. Az elengedés nem vált vissza másik fülre.

Ugróhostok / Jump hosts (1.5.0)
1. Mentsd el az ugróhostot a Hosts listában a saját felhasználónevével és
   jelszavával vagy privát kulcsával.
2. A célhostnál kattints az Edit gombra. A „Jump hosts (in connection order)”
   résznél válaszd ki az ugróhostot; több host is felvehető. Az ↑ gombbal
   módosítható a sorrend, a Remove gombbal törölhető egy lépés.
3. Save changes, majd Connect. Minden köztes host saját beállításai érvényesek;
   ha az ugróhostnak is van ugróhostja, azon keresztül indul a kapcsolat.
A terminál, az SFTP és a Local/Remote/Dynamic port forwarding is ezt az
útvonalat használja. A célhost nevét a köztes SSH-szerver oldja fel. Minden
lépés ujjlenyomatát külön ellenőrzi az app. A körkörös és hiányos útvonalakat
elutasítja; legfeljebb nyolc SSH-host lehet egy láncban, a célhosttal együtt.
A kapcsolati útvonal a többi hostadattal együtt a titkosított vaultba mentődik.
A Termiusból importált ugróhostoknál az Edit ablak felajánlja a megőrzött
hivatkozásokból azonosítható hostokat. Ellenőrizd a sorrendet, majd mentsd el.
A meglévő vault használható. Ugróhostos vault módosításához 1.5.0 vagy újabb
LocalTermet használj. Útvonalban használt host törlése előtt távolítsd el a
rá mutató ugróhost-hivatkozásokat. Aktív tunnel hostadatainak módosítása
leállítja a tunnelt; az új útvonalhoz indítsd újra.

Utolsó vault és ugróhost-kereső (1.5.1)
A LocalTerm megjegyzi az utoljára sikeresen megnyitott vagy létrehozott vault
útvonalát. Következő induláskor az Unlock vault gombbal közvetlenül feloldható;
a fájlválasztót csak akkor kell használni, ha másik fájlt szeretnél megnyitni.
A jelszót minden indításkor be kell írni. Csak a fájlútvonal kerül a számítógép
helyi alkalmazásbeállításaiba; a vault tartalma továbbra is titkosított.
Ha a fájlt áthelyezted, válaszd ki újra a Choose a vault file gombbal.
A Jump hosts választó ABC-sorrendben mutatja a hostokat, és a Search jump hosts
mezőben névre, szervercímre, felhasználónévre vagy csoportra is kereshetsz.
A már kiválasztott ugróhostok kapcsolati sorrendjét a rendezés nem változtatja.

Kilépés és duplikálás (1.5.2)
Ha az SSH-munkamenet lezárul (például exit, Ctrl+D vagy kapcsolatmegszakadás),
a terminálpanel és a füle automatikusan eltűnik. Osztott nézetben a többi panel
kitölti a helyét; az utolsó bezárásakor a hostlista jelenik meg. A háttérben
megszűnő kapcsolat nem visz el a hostlistából vagy a megnyitott hostválasztóból.
Jobb kattintás egy terminál fülén → Duplicate: új, független SSH-kapcsolat nyílik
ugyanahhoz a mentett hosthoz, a jelenlegi hitelesítéssel és ugróhost-útvonallal.
Az eredeti kapcsolat megmarad. Az új kapcsolat külön, teljes méretű fülön nyílik.
Workspace-fülön a legutóbb kijelölt tag duplikálódik. Az adott panel fejlécén is
elérhető ugyanez a menü. A Duplicate nem másolja át a távoli shell folyamatait
vagy munkakönyvtárát; új bejelentkezést indít.

Hostkereső automatikus fókusza (1.5.3)
A Hosts menü megnyitásakor a Search hosts mező automatikusan fókuszt kap,
így kattintás nélkül azonnal gépelhetsz. Vaultfeloldáskor, a terminálból
visszatérve és hostcsoport választásakor is a hostkereső aktív.

Automatikus zárolás beállítása (1.5.4)

Vault settings → Automatic vault locking:
- Enable automatic locking: az összes automatikus zárolás be/ki kapcsolása.
- Lock after inactivity: 1–1440 perc között állítható.
- Külön kapcsoló a képernyőzárhoz és a számítógép alvó módjához.
- Save locking settings: azonnal menti és alkalmazza a beállításokat.

Kikapcsolt főkapcsolónál a képernyő zárolása és az alvó mód sem zárolja
a vaultot. A kézi Lock vault és az alkalmazásból való kilépés továbbra is
zárol. A beállítások a titkosított vaultban vannak, újranyitáskor megmaradnak.
A billentyűzet és az egér használata aktivitásnak számít; a távoli terminál
magától érkező kimenete nem indítja újra az időzítőt.

Terminálvágólap (1.5.5)

Kijelöléskor a szöveg automatikusan a rendszer vágólapjára kerül.
Jobb kattintás a terminálon: beillesztés a kattintott panelbe.
Alapból bekapcsolt. Ki- és bekapcsolás: Vault settings → Terminal clipboard
→ Copy selection and paste on right-click → Save clipboard settings.
A választás a titkosított vaultban megmarad, és a nyitott terminálokra is érvényes.
A fülek Duplicate menüje és a billentyűs másolás/beillesztés megmarad.
A rendszer vágólapját a vault zárolása nem törli.

Hostonkénti témák (1.5.6)

Hosts → Edit → Terminal theme: Default, Ember Dune, Emerald, Paper vagy Custom.
A Default minden hostnál a korábbi LocalTerm-színeket tartja meg.
Custom: háttér, betűszín, kurzor, kijelölés háttere és kijelölt szöveg színe,
színválasztóval és hex mezőkkel, élő előnézettel.
Save changes: mentés a titkosított vaultba; a host nyitott termináljai is frissülnek.
