'use strict';
const $ = id => document.getElementById(id);
const usesControlShortcuts=['win32','linux'].includes(window.api.platform);
const shortcutLabel=usesControlShortcuts?'Ctrl+':'⌘';
const state = { locked: true, path: '', data: null, view: 'hosts', group: '', sessions: new Map(), workspaces: new Map(), activeWorkspace: null, pickerTabs: new Map(), tabOrder: [], activePicker: null, active: null, epoch: 0, layout: 1, dockTree: null, dragSession: null, slots: [], focusSlot: 0, forwards: new Map() };
let toastTimer;
function notify(message, success = false) { clearTimeout(toastTimer); $('toast').textContent = message; $('toast').classList.toggle('success', success); $('toast').hidden = false; toastTimer = setTimeout(() => $('toast').hidden = true, 7000); }
async function call(method, payload = {}) { const result = await window.api.call(method, payload); if (result?.error) throw new Error(result.error); return result; }
function action(fn) { return async event => { try { await fn(event); } catch (error) { notify(error.message || String(error)); } }; }
function el(tag, className, text) { const e = document.createElement(tag); if (className) e.className = className; if (text !== undefined) e.textContent = text; return e; }
function button(text, className, fn) { const b = el('button', className, text); b.type = 'button'; b.addEventListener('click', action(fn)); return b; }
function closeSessions() {window.sftpBrowser?.reset();hideTerminalMenu();state.workspaces.clear();state.activeWorkspace=null;state.pickerTabs.clear();state.activePicker=null;$('host-picker').hidden=true;$('host-picker-search').value='';$('host-picker-results').replaceChildren(); clearTerminalDrag();state.dockTree=null; for (const session of state.sessions.values()) { session.term.dispose(); session.unobserve?.(); } for(const timer of logTimers.values())clearTimeout(timer);logTimers.clear();$('terminal-logs').replaceChildren();$('terminal-logs').hidden=true;state.sessions.clear(); state.active = null; state.slots=[]; state.focusSlot=0; $('workspace').classList.remove('terminal-mode'); $('terminal-tabs').replaceChildren(); $('terminal-panes').replaceChildren();updateReturnButton(); }
function applyVault(result) { if (!result || result.canceled || result.cancelled) return; const wasLocked = state.locked; Object.assign(state, result); $('welcome').hidden = !state.locked; $('workspace').hidden = state.locked; if (state.locked) { state.epoch++; state.data = null; state.forwards.clear(); closeSessions(); for (const dialog of document.querySelectorAll('dialog[open]:not(#update-progress)')) dialog.close(); $('editor-fields').replaceChildren(); $('editor-form').onsubmit=null; $('items').replaceChildren(); $('file-list').replaceChildren(); $('new-password').value = '';$('import-password').value=''; $('create-password').value = ''; $('create-confirm').value = ''; $('vault-password').value = ''; $('selected-file').hidden = !state.path; $('selected-file').textContent = state.path || ''; $('unlock-button').textContent = state.path ? 'Unlock vault' : 'Open encrypted vault'; $('vault-password').focus(); } else { state.data.forwards ||= []; if (wasLocked) { state.view = 'hosts'; state.group = ''; $('search').value = ''; } $('vault-password').value = ''; $('vault-path').textContent = state.path; $('vault-path').title = state.path; $('settings-path').textContent = state.path; render(); if(wasLocked){refreshForwards();focusHostSearch();call('update:check',{manual:false}).catch(()=>{});}if(result.preferenceWarning)notify(result.preferenceWarning); } }
async function save(data) { const result = await call('vault:save', { data }); state.data = result?.data || data; applyTerminalThemes(); render(); }
function focusHostSearch(){if(!state.locked&&state.view==='hosts'&&!$('library').hidden&&!document.querySelector('dialog[open]'))$('search').focus({preventScroll:true});}
function switchView(view) { state.view = view; state.group = ''; $('search').value = ''; render();if(view==='hosts')focusHostSearch(); }
const names = { hosts: ['Hosts', 'All your servers, one place to connect.', 'host'], keys: ['Keys', 'Private keys, protected inside your vault.', 'key'], snippets: ['Snippets', 'Your useful commands, ready when you are.', 'snippet'], forwards: ['Port forwarding', 'Secure tunnels through your SSH hosts.', 'forwarding rule'] };
function render() {
 $('terminal-logs').hidden=true; $('sftp-browser').hidden=true;
 hideTerminalMenu();
 state.activePicker=null;$('host-picker').hidden=true;
 if (!state.data) return;
 const openingHosts=state.view==='hosts'&&$('library').hidden;
 $('workspace').classList.remove('terminal-mode'); $('library').hidden = false; $('sessions').hidden = true;
 const [title, subtitle, singular] = names[state.view];
 updateReturnButton();
 $('items').classList.toggle('compact-cards',state.view!=='snippets');
 $('breadcrumb').textContent = title; $('page-title').textContent = state.group || title; $('page-subtitle').textContent = subtitle; $('add-item').textContent = `＋ New ${singular}`; $('search').placeholder = `Search ${title.toLowerCase()}…`;
 document.querySelectorAll('[data-view]').forEach(b => b.classList.toggle('active', b.dataset.view === state.view));
 for (const [collection, id] of [['hosts','host-count'],['keys','key-count'],['snippets','snippet-count'],['forwards','forward-count']]) $(id).textContent = state.data[collection].length;
 const groups = [...new Set(state.data.hosts.map(h => h.group).filter(Boolean))].sort(); $('groups').replaceChildren(); if (groups.length) { $('groups').append(el('div','nav-label','GROUPS')); groups.forEach(group => { const b = button(`◷  ${group}`, state.group === group ? 'active' : '', () => { state.view = 'hosts'; state.group = group; render();focusHostSearch(); }); $('groups').append(b); }); }
 const query = $('search').value.toLowerCase(); const items = state.data[state.view].filter(item => (!state.group || item.group === state.group) && [item.label,item.address,item.username,item.group,item.notes,item.command,item.type,item.bindAddress,item.targetAddress].filter(Boolean).join(' ').toLowerCase().includes(query));
 $('result-count').textContent = `${items.length} ${items.length === 1 ? singular : title.toLowerCase()}`;
 $('items').replaceChildren();
 if (!items.length) { const empty = el('div','empty'); empty.append(el('div','empty-icon', state.view === 'hosts' ? '›_' : state.view === 'keys' ? '⚿' : '⌘'),el('h3',null,query || state.group ? 'No matches found' : `Your ${title.toLowerCase()} will live here`),el('p',null,query || state.group ? 'Try a different search or group.' : `Add your first ${singular} to this encrypted vault.`)); if (!query && !state.group) empty.append(button(`＋ Add ${singular}`,'primary',()=>editItem())); $('items').append(empty); }
 const collection=state.view;
 for(const item of items){
   if(collection==='forwards'){
     $('items').append(forwardCard(item));
     continue;
   }
   const isHost=collection==='hosts';
   const isKey=collection==='keys';
   const card=el('article',isHost?'card compact-card host-card':isKey?'card compact-card':'card');
   const top=el('div','card-top');
   const meta=el('div');
   const title=el('h3',null,item.label);
   title.title=item.label;
   const address=isHost?`${item.username}@${item.address}:${item.port || 22}`:isKey?'Private key · encrypted':'Shell command';
   const description=el('div','address',address);
   description.title=address;
   meta.append(title,description);
   top.append(el('div','host-icon',isHost?'›_':isKey?'⚿':'⌘'),meta);
   card.append(top);
   if(item.group)card.append(el('span','group-tag',item.group));
   if(collection==='snippets')card.append(el('div','note',item.command));
   else if(item.notes)card.append(el('div','note',item.notes));
   const actions=el('div','card-actions');
   if(isHost){
     actions.append(button('Connect ↗','connect',event=>{
       if(event.detail<=1)return connect(item);
     }));
     card.addEventListener('dblclick',action(event=>{
       if(!event.target.closest('button'))return connect(item);
     }));
   }
   if(collection==='snippets')actions.append(button('Run in session','connect',()=>runSnippet(item)));
   actions.append(button('Edit','subtle',()=>editItem(item,collection)),button('Delete','subtle',()=>deleteItem(item,collection)));
   card.append(actions);
   $('items').append(card);
 }
 if(state.sessions.size){const resume=button(`›_ Return to session (${state.sessions.size})`,'subtle wide',returnToSession);$('items').append(resume);}
 if(openingHosts)focusHostSearch();
}
async function deleteItem(item,collection) { if (!confirm(`Delete “${item.label}” from this vault?`)) return; if(collection==='forwards' && state.forwards.has(item.id))await call('forward:stop',{ruleId:item.id}); if(collection==='hosts'){for(const f of state.data.forwards.filter(f=>f.hostId===item.id)){if(state.forwards.has(f.id))await call('forward:stop',{ruleId:f.id});}} const data=structuredClone(state.data);if(collection==='hosts')data.forwards=data.forwards.filter(f=>f.hostId!==item.id); data[collection]=data[collection].filter(i=>i.id!==item.id); if(collection==='keys')data.hosts.forEach(h=>{if(h.keyId===item.id)h.keyId='';}); await save(data); }
function field(name,label,value='',type='text',required=false) {const wrap=el('label',null,label);let input;if(type==='textarea'){input=el('textarea');input.rows=name==='privateKey'?8:3;}else{input=el('input');input.type=type;}input.name=name;input.value=value??'';input.required=required;input.autocomplete='off';if(['port','bindPort','targetPort'].includes(name)){input.min='1';input.max='65535';}wrap.append(input);return wrap;}
function editItem(item=null,collection=state.view) {
 $('editor-title').textContent=`${item?'Edit':'New'} ${names[collection][2]}`; const fields=$('editor-fields');fields.replaceChildren();fields.append(field('label','Label',item?.label,'text',true));
 if(collection==='hosts') { fields.append(field('address','Server address',item?.address,'text',true));const row=el('div','field-row');row.append(field('username','Username',item?.username||'root','text',true),field('port','Port',item?.port||22,'number',true));fields.append(row,field('group','Group',item?.group),field('password','Password (optional)',item?.password,'password')); const label=el('label',null,'Private key');const select=el('select');select.name='keyId';const opt=el('option',null,'No private key');opt.value='';select.append(opt);state.data.keys.forEach(k=>{const o=el('option',null,k.label);o.value=k.id;select.append(o);});select.value=item?.keyId||'';label.append(select);fields.append(label);editJumpHosts(fields,item);editSshKeepAlive(fields,item);editTerminalTheme(fields,item);fields.append(field('notes','Notes',item?.notes,'textarea')); if(item)fields.append(button('Forget saved SSH fingerprint…','wide',async()=>{const address=fields.querySelector('[name=address]').value;const port=Number(fields.querySelector('[name=port]').value);if(!confirm(`Forget the trusted SSH fingerprint for ${address}:${port}?\n\nYou will be asked to verify the server again on the next connection.`))return;const result=await call('vault:forgetHost',{address,port});if(result?.data)state.data=result.data;notify('Saved SSH fingerprint removed.',true);})); }
 if(collection==='keys'){fields.append(field('privateKey','Private key (PEM / OpenSSH)',item?.privateKey,'textarea',true));fields.append(button('Import key from file…','wide',async()=>{const result=await call('key:read');if(result?.privateKey)fields.querySelector('[name=privateKey]').value=result.privateKey;}),field('passphrase','Key passphrase (optional)',item?.passphrase,'password'));}
 if(collection==='forwards')editForwardFields(fields,item);
 if(collection==='snippets')fields.append(field('command','Command',item?.command,'textarea',true));
 $('editor-form').onsubmit=action(async event=>{event.preventDefault();const values=Object.fromEntries(new FormData(event.currentTarget));if(collection==='hosts'){values.port=Number(values.port);values.sshKeepAlive=values.sshKeepAlive==='on';}if(collection==='forwards'){values.bindPort=Number(values.bindPort);if(values.type==='dynamic'){delete values.targetAddress;delete values.targetPort;}else values.targetPort=Number(values.targetPort);if(item&&state.forwards.has(item.id))await call('forward:stop',{ruleId:item.id});}const data=structuredClone(state.data);const record={...item,...values,id:item?.id||crypto.randomUUID()};if(collection==='hosts'){record.terminalTheme=fields.terminalTheme();record.jumpHostIds=fields.jumpHostIds();delete record.jumpHostId;record.migrationBlockers=record.migrationBlockers?.filter(text=>!/jump-host/i.test(text));record.requiresMigrationSetup=!!record.migrationBlockers?.length||!record.username?.trim();}if(collection==='forwards'&&record.type==='dynamic'){delete record.targetAddress;delete record.targetPort;}const index=data[collection].findIndex(i=>i.id===record.id);if(index<0)data[collection].push(record);else data[collection][index]=record;await save(data);$('editor').close();fields.replaceChildren();});$('editor').showModal();
}
function editSshKeepAlive(fields, item) {
 const label = el('label', null, 'SSH keepalive');
 const select = el('select');
 select.name = 'sshKeepAlive';
 for (const [value, text] of [['on', 'On (default)'], ['off', 'Off']]) {
  const option = el('option', null, text);
  option.value = value;
  select.append(option);
 }
 select.value = item?.sshKeepAlive === false ? 'off' : 'on';
 label.append(select);
 fields.append(label);
}
function editTerminalTheme(fields,item){
 const themes=window.LocalTermThemes;let preset=item?.terminalTheme?.preset||'default';let custom=preset==='custom'?themes.resolve(item.terminalTheme):null;
 const section=el('section','host-terminal-theme');section.append(el('h3',null,'Terminal theme'),el('p','muted','Colors for this host. Default keeps the current LocalTerm theme. Saving also updates its open terminals.'));
 const choices=el('div','theme-options');choices.setAttribute('role','group');choices.setAttribute('aria-label','Terminal theme');const buttons=new Map();const controls=new Map();
 const preview=el('div','theme-preview');preview.setAttribute('aria-label','Terminal theme preview');const prompt=el('div',null,`${item?.username||'user'}@${item?.label||'host'} ~`);const sample=el('div',null,'Documents/  README.md');const selected=el('span','theme-selection','Selected text');const cursor=el('span','theme-cursor','█');const bottom=el('div');bottom.append(selected,document.createTextNode('  '),cursor);preview.append(prompt,sample,bottom);
 const customFields=el('div','theme-color-fields');const labels={background:'Background',foreground:'Text',cursor:'Cursor',selectionBackground:'Selection background',selectionForeground:'Selected text'};
 const colors=()=>preset==='custom'?{...themes.PRESETS.default.colors,...custom}:themes.resolve({preset});
 function redraw(){const palette=colors();for(const [id,b] of buttons){b.setAttribute('aria-pressed',String(id===preset));b.classList.toggle('selected',id===preset);}customFields.hidden=preset!=='custom';for(const {picker,hex} of controls.values()){picker.disabled=hex.disabled=preset!=='custom';}preview.style.backgroundColor=palette.background;preview.style.color=palette.foreground;prompt.style.color=palette.green||palette.foreground;selected.style.backgroundColor=palette.selectionBackground;selected.style.color=palette.selectionForeground||palette.foreground;cursor.style.color=palette.cursor;}
 for(const [id,definition] of [...Object.entries(themes.PRESETS),['custom',{label:'Custom',colors:custom||themes.PRESETS.default.colors}]]){
  const b=button('','theme-choice',()=>{const previous=colors();if(id==='custom'&&!custom){custom=Object.fromEntries(themes.COLOR_KEYS.map(k=>[k,previous[k]||previous.foreground]));for(const [key,{picker,hex}] of controls){picker.value=hex.value=custom[key];}}preset=id;redraw();});b.dataset.terminalTheme=id;
  const miniature=el('span','theme-miniature');miniature.style.backgroundColor=definition.colors.background;miniature.style.color=definition.colors.foreground;miniature.append(el('span',null,'›_'),el('span','theme-mini-line','━━━━━━'),el('span','theme-mini-selected','━━━'));miniature.lastChild.style.backgroundColor=definition.colors.selectionBackground;b.append(miniature,el('span',null,definition.label));choices.append(b);buttons.set(id,b);
 }
 for(const key of themes.COLOR_KEYS){
  const label=el('label','theme-color-label',labels[key]);const row=el('div','theme-color-inputs');const picker=el('input');picker.type='color';picker.dataset.themeColor=key;picker.setAttribute('aria-label',`Terminal ${labels[key].toLowerCase()} color`);const hex=el('input');hex.type='text';hex.dataset.themeHex=key;hex.setAttribute('aria-label',`Terminal ${labels[key].toLowerCase()} hex color`);hex.pattern='#[0-9a-fA-F]{6}';hex.maxLength=7;hex.required=true;hex.spellcheck=false;hex.autocomplete='off';picker.value=hex.value=(custom||themes.PRESETS.default.colors)[key]||themes.PRESETS.default.colors.foreground;
  picker.addEventListener('input',()=>{custom ||= {};custom[key]=picker.value;hex.value=picker.value;hex.setCustomValidity('');redraw();});hex.addEventListener('input',()=>{const valid=themes.isColor(hex.value);hex.setCustomValidity(valid?'':'Use a six-digit hex color, for example #7a251e.');if(valid){custom ||= {};custom[key]=hex.value;picker.value=hex.value;redraw();}});row.append(picker,hex);label.append(row);customFields.append(label);controls.set(key,{picker,hex});
 }
 section.append(choices,customFields,preview);fields.append(section);redraw();fields.terminalTheme=()=>{const value=preset==='custom'?{preset,colors:Object.fromEntries([...controls].map(([key,{hex}])=>[key,hex.value]))}:{preset};themes.validate(value);return value;};
}
function applySessionTheme(session){const host=state.data?.hosts.find(h=>h.id===session.host.id)||session.host;const palette=window.LocalTermThemes.resolve(host.terminalTheme);session.term.options.theme=palette;session.content.style.backgroundColor=palette.background;session.pane.style.backgroundColor=palette.background;}
function applyTerminalThemes(){for(const session of state.sessions.values())applySessionTheme(session);}

function editJumpHosts(fields,item){
 const section=el('div','jump-host-editor');section.append(el('label',null,'Jump hosts (in connection order)'));
 let ids=[...(item?.jumpHostIds??(item?.jumpHostId?[item.jumpHostId]:[]))];
 if(item?.jumpHostIds===undefined&&!item?.jumpHostId&&item?.sourceMetadata?.jumpHostIds?.length){
  const resolved=item.sourceMetadata.jumpHostIds.map(sourceId=>state.data.hosts.find(h=>h.sourceApp==='Termius'&&h.sourceId===sourceId)?.id);
  if(resolved.every(Boolean))ids=[...new Set(resolved)];
  section.append(el('p','muted','Imported route: review the selected jump hosts before saving. Saving a direct route removes the imported jump-host requirement.'));
 }
 const search=el('input');search.type='search';search.placeholder='Search jump hosts…';search.setAttribute('aria-label','Search jump hosts');const matches=el('p','muted');matches.setAttribute('role','status');const list=el('div','jump-host-list');const select=el('select');select.setAttribute('aria-label','Add jump host');
 function draw(){list.replaceChildren();ids.forEach((id,index)=>{const row=el('div','jump-host-row');row.append(el('span',null,`${index+1}. ${state.data.hosts.find(h=>h.id===id)?.label||'Missing host'}`));if(index)row.append(button('↑','subtle',()=>{[ids[index-1],ids[index]]=[ids[index],ids[index-1]];draw();}));row.append(button('Remove','subtle',()=>{ids.splice(index,1);draw();}));list.append(row);});select.replaceChildren();const direct=el('option',null,ids.length?'Add another jump host…':'Direct connection — add a jump host…');direct.value='';select.append(direct);const query=search.value.trim().toLocaleLowerCase();const candidates=state.data.hosts.filter(host=>host.id!==item?.id&&!ids.includes(host.id)&&[host.label,host.address,host.username,host.group].filter(Boolean).join(' ').toLocaleLowerCase().includes(query)).sort((a,b)=>a.label.localeCompare(b.label,undefined,{sensitivity:'base',numeric:true})||a.address.localeCompare(b.address)||a.id.localeCompare(b.id));matches.textContent=candidates.length?`${candidates.length} available ${candidates.length===1?'host':'hosts'}`:'No matching jump hosts';select.disabled=!candidates.length;for(const host of candidates){const option=el('option',null,`${host.label} · ${host.username}@${host.address}`);option.value=host.id;select.append(option);}select.value='';}
 search.addEventListener('input',draw);select.addEventListener('change',()=>{if(select.value)ids.push(select.value);search.value='';draw();});section.append(list,search,select,matches,el('p','muted','Each jump host uses its own saved credentials and SSH fingerprint. Its own jump route is followed first.'));fields.append(section);fields.jumpHostIds=()=>[...ids];draw();
}
function terminalMode(){$('terminal-logs').hidden=true;$('sftp-browser').hidden=true; $('workspace').classList.add('terminal-mode'); $('library').hidden=true; $('sessions').hidden=false; }
function fitVisible(){for(const id of state.slots){const s=state.sessions.get(id);if(s){s.fit.fit();if(!s.closed)call('ssh:resize',{id:s.id,cols:s.term.cols,rows:s.term.rows}).catch(()=>{});}}}
// Each split belongs to one tab. The live layout is saved before switching tabs.
function saveWorkspace(){
 const ids=state.slots.filter(id=>state.sessions.has(id));
 for(const [key,g] of state.workspaces){if(key===state.activeWorkspace)continue;g.slots=g.slots.filter(id=>state.sessions.has(id)&&!ids.includes(id));g.tree=pruneWorkspaceTree(g.tree,g.slots);if(g.slots.length<2)state.workspaces.delete(key);}
 if(ids.length>1){state.activeWorkspace ||= crypto.randomUUID();state.workspaces.set(state.activeWorkspace,{slots:[...state.slots],layout:state.layout,tree:state.dockTree,active:state.active,focusSlot:state.focusSlot});}
 else if(state.activeWorkspace){state.workspaces.delete(state.activeWorkspace);state.activeWorkspace=null;}
}
function pruneWorkspaceTree(tree,ids){if(!tree)return null;if(!tree.axis)return ids.includes(tree.id)?tree:null;const first=pruneWorkspaceTree(tree.first,ids),second=pruneWorkspaceTree(tree.second,ids);return first&&second?{...tree,first,second}:first||second;}
function showWorkspace(key){saveWorkspace();const g=state.workspaces.get(key);if(!g)return;state.activeWorkspace=key;state.slots=[...g.slots];state.layout=g.layout;state.dockTree=g.tree;state.active=g.active;state.focusSlot=g.focusSlot;renderTerminals();}
function singleSession(id){state.activeWorkspace=null;state.slots=[id];state.layout=1;state.dockTree=null;state.active=id;state.focusSlot=0;}
function setLayout(count){if(count==='custom')return;state.dockTree=null;state.layout=Math.max(1,Math.min(3,Number(count)));state.focusSlot=Math.min(state.focusSlot,state.layout-1);const active=state.active;state.slots=state.slots.slice(0,state.layout);if(active&&!state.slots.includes(active))state.slots[state.focusSlot]=active;fillSlots();renderTerminals();}
function fillSlots(){state.slots=state.slots.map(id=>state.sessions.has(id)?id:null);while(state.slots.length<state.layout)state.slots.push(null);for(let i=0;i<state.layout;i++){if(!state.slots[i])state.slots[i]=[...state.sessions.keys()].find(id=>!state.slots.includes(id)&&![...state.workspaces.entries()].some(([key,g])=>key!==state.activeWorkspace&&g.slots.includes(id)))||null;}}
function selectSlot(index,id){const previous=state.slots[index];const other=state.slots.indexOf(id);if(other>=0&&other!==index)state.slots[other]=previous;state.slots[index]=id;state.focusSlot=index;state.active=id;renderTerminals();}
function slotSelect(index,current){const select=el('select','pane-session-select');select.setAttribute('aria-label',`Session for column ${index+1}`);const empty=el('option',null,'Select a terminal');empty.value='';empty.disabled=true;select.append(empty);for(const s of state.sessions.values()){const option=el('option',null,`${s.closed?'○':'●'} ${s.host.label}`);option.value=s.id;select.append(option);}select.value=current||'';select.addEventListener('change',()=>selectSlot(index,select.value));return select;}
function focusPane(id,focus=true){const index=state.slots.indexOf(id);if(index<0)return;state.focusSlot=index;state.active=id;for(const s of state.sessions.values())s.pane.classList.toggle('focused',s.id===id);for(const tab of $('terminal-tabs').children)tab.classList.toggle('active',tab.dataset.workspace===state.activeWorkspace&&!!state.activeWorkspace||tab.dataset.session===id);const session=state.sessions.get(id);$('session-label').textContent=`${session.host.username}@${session.host.address} · ${session.closed?'Disconnected':'SSH'}`;$('files-button').disabled=session.closed;if(state.activeWorkspace){const g=state.workspaces.get(state.activeWorkspace);if(g){g.active=id;g.focusSlot=index;}}if(focus)session.term.focus();}
async function closeSession(id){
 const session=state.sessions.get(id);if(!session||session.closing)return;session.closing=true;await persistTerminalLog(session);hideTerminalMenu();
 saveWorkspace();const wasVisible=state.slots.includes(id),previousSlot=state.focusSlot;
 try{if(!session.closed)await call('ssh:close',{id});}catch(error){session.closing=false;throw error;}
 if(state.sessions.get(id)!==session)return;
 clearTerminalDrag();session.unobserve?.();session.term.dispose();session.pane.remove();state.sessions.delete(id);
 for(const [key,g] of state.workspaces){g.slots=g.slots.filter(value=>value!==id);g.tree=pruneWorkspaceTree(g.tree,g.slots);g.layout=g.slots.length;if(g.active===id)g.active=g.slots[0];if(g.slots.length<2)state.workspaces.delete(key);}
 if(!state.sessions.size){state.active=null;state.slots=[];state.layout=1;state.dockTree=null;state.activeWorkspace=null;state.focusSlot=0;render();return;}
 if(wasVisible){state.slots=state.slots.filter(value=>value!==id&&state.sessions.has(value));state.dockTree=pruneWorkspaceTree(state.dockTree,state.slots);state.layout=state.slots.length;if(state.layout<2){state.dockTree=null;state.activeWorkspace=null;}
  if(!state.slots.length){const next=state.sessions.keys().next().value;state.activeWorkspace=null;state.slots=[];showSession(next);return;}
 }
 if(!state.slots.includes(state.active))state.active=state.slots[Math.min(previousSlot,state.slots.length-1)]||state.slots.find(Boolean);
 state.focusSlot=Math.max(0,state.slots.indexOf(state.active));renderTerminals();
}

async function handleSessionClosed(id){
 await persistTerminalLog(state.sessions.get(id));
 const picker=state.activePicker,libraryVisible=!$('library').hidden;
 await closeSession(id);
 if(state.locked)return;
 if(picker&&state.pickerTabs.has(picker))showHostPicker(picker);
 else if(libraryVisible)render();
 updateReturnButton();
}
function hideTerminalMenu(){const menu=$('terminal-context-menu');menu.hidden=true;menu.replaceChildren();}
function terminalMenu(target,getId){target.addEventListener('contextmenu',event=>{
 event.preventDefault();event.stopPropagation();clearTerminalDrag();hideTerminalMenu();
 const id=getId(),session=state.sessions.get(id);if(state.locked||!session||session.closed||session.closing)return;
 const menu=$('terminal-context-menu');menu.setAttribute('aria-label',`Terminal actions: ${session.host.label}`);
 const duplicate=button('Duplicate','',()=>{hideTerminalMenu();const current=state.sessions.get(id);if(state.locked||!current||current.closed)return;const host=state.data.hosts.find(h=>h.id===current.host.id);if(!host)throw Error('This host was deleted from the vault.');return connect(host);});duplicate.setAttribute('role','menuitem');menu.append(duplicate,button('Close terminal','',()=>{hideTerminalMenu();closeSession(id);}));for(const [label,count] of [['Single terminal',1],['2 columns',2],['3 columns',3]])menu.append(button('Layout: '+label,'',()=>{hideTerminalMenu();showSession(id);setLayout(count);}));menu.append(button('Browse files','',()=>{hideTerminalMenu();showSession(id);$('files-button').click();}),button('Lock vault','',()=>{hideTerminalMenu();$('terminal-lock').click();}));menu.hidden=false;
 const rect=menu.getBoundingClientRect();menu.style.left=`${Math.max(4,Math.min(event.clientX,window.innerWidth-rect.width-4))}px`;menu.style.top=`${Math.max(4,Math.min(event.clientY,window.innerHeight-rect.height-4))}px`;duplicate.focus();
 });}
document.addEventListener('pointerdown',event=>{if(!$('terminal-context-menu').contains(event.target))hideTerminalMenu();},true);
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!$('terminal-context-menu').hidden){hideTerminalMenu();event.preventDefault();if(state.activePicker)$('host-picker-search').focus();else state.sessions.get(state.active)?.term.focus();}});
window.addEventListener('blur',hideTerminalMenu);window.addEventListener('resize',hideTerminalMenu);
function clearTerminalDrag(){clearTimeout(dragTabHoverTimer);dragTabHoverTimer=null;dragTabHoverKey=null;pointerTerminalDrag=null;state.dragSession=null;document.body.classList.remove('terminal-dragging');document.querySelectorAll('[data-tab-drop]').forEach(tab=>delete tab.dataset.tabDrop);document.querySelectorAll('[data-drop-zone]').forEach(p=>delete p.dataset.dropZone);}
function dockLeaves(node){return node?(node.axis?[...dockLeaves(node.first),...dockLeaves(node.second)]:[node.id]):[];}
function dockMap(node,fn){return node.axis?{...node,first:dockMap(node.first,fn),second:dockMap(node.second,fn)}:fn(node);}
function dockRemove(node,id){if(!node)return null;if(!node.axis)return node.id===id?null:node;const first=dockRemove(node.first,id),second=dockRemove(node.second,id);return first&&second?{...node,first,second}:first||second;}
function dockRects(node,rect={x:0,y:0,w:100,h:100},out=[]){if(!node.axis){out.push({id:node.id,...rect});return out;}const a=dockLeaves(node.first).length,b=dockLeaves(node.second).length;const ratio=a/(a+b);if(node.axis==='x'){dockRects(node.first,{...rect,w:rect.w*ratio},out);dockRects(node.second,{...rect,x:rect.x+rect.w*ratio,w:rect.w*(1-ratio)},out);}else{dockRects(node.first,{...rect,h:rect.h*ratio},out);dockRects(node.second,{...rect,y:rect.y+rect.h*ratio,h:rect.h*(1-ratio)},out);}return out;}
function horizontalDock(ids){return ids.length===1?{id:ids[0]}:{axis:'x',first:{id:ids[0]},second:horizontalDock(ids.slice(1))};}
function makeTerminalDraggable(element,id){element.draggable=false;element.dataset.terminalDrag='true';element.addEventListener('pointerdown',event=>{if(event.button!==0||state.locked||event.target.closest('select,option,.pane-close')||event.target.textContent==='×')return;pointerTerminalDrag={id,tabKey:element.dataset.tabKey||null,x:event.clientX,y:event.clientY,started:false};});element.title='Drag to arrange terminals';element.addEventListener('dragstart',event=>{if(state.locked||!state.sessions.has(id)){event.preventDefault();return;}state.dragSession=id;event.dataTransfer?.setData('application/x-localterm-session',id);if(event.dataTransfer)event.dataTransfer.effectAllowed='move';document.body.classList.add('terminal-dragging');});element.addEventListener('dragend',clearTerminalDrag);}
function dropZone(event,pane){const r=pane.getBoundingClientRect();const x=r.width?(event.clientX-r.left)/r.width:.5,y=r.height?(event.clientY-r.top)/r.height:.5;const edges=[['left',x],['right',1-x],['top',y],['bottom',1-y]].sort((a,b)=>a[1]-b[1]);return edges[0][1]<.25?edges[0][0]:'center';}
function makeTerminalDropTarget(pane,getIndex){pane.addEventListener('dragover',event=>{if(!state.dragSession||state.locked||!state.sessions.has(state.dragSession))return;event.preventDefault();if(event.dataTransfer)event.dataTransfer.dropEffect='move';document.querySelectorAll('[data-drop-zone]').forEach(p=>{if(p!==pane)delete p.dataset.dropZone;});pane.dataset.dropZone=dropZone(event,pane);});pane.addEventListener('dragleave',event=>{if(!pane.contains(event.relatedTarget))delete pane.dataset.dropZone;});pane.addEventListener('drop',event=>{const source=state.dragSession;if(!source||state.locked||!state.sessions.has(source))return;event.preventDefault();event.stopPropagation();const index=getIndex(),zone=dropZone(event,pane);clearTerminalDrag();dockSession(source,index,zone);});}
function dockSession(source,index,zone){const target=state.slots[index];if(index<0||source===target)return;if(zone==='center'||!target){selectSlot(index,source);return;}let tree=state.dockTree||horizontalDock(state.slots.filter(Boolean));tree=dockRemove(tree,source);if(dockLeaves(tree).length>=6){notify('Up to six terminals can be arranged at once. Drop in the center to replace a pane.');return;}const first=['left','top'].includes(zone);tree=dockMap(tree,node=>node.id===target?{axis:['left','right'].includes(zone)?'x':'y',first:{id:first?source:target},second:{id:first?target:source}}:node);state.dockTree=tree;state.slots=dockLeaves(tree);state.layout=state.slots.length;state.focusSlot=state.slots.indexOf(source);state.active=source;renderTerminals();}

function renderTerminals(){if(!state.sessions.size)return;state.activePicker=null;$('host-picker').hidden=true;$('terminal-tools').hidden=false;$('terminal-panes').hidden=false;terminalMode();fillSlots();saveWorkspace();if(state.dockTree){let i=0;state.dockTree=dockMap(state.dockTree,()=>({id:state.slots[i++]}));}$('terminal-layout').value=state.dockTree?'custom':String(state.layout);$('terminal-panes').classList.toggle('docked',!!state.dockTree);$('terminal-panes').style.gridTemplateColumns=`repeat(${state.layout}, minmax(0,1fr))`;$('terminal-panes').querySelectorAll('.empty-terminal').forEach(p=>p.remove());for(const s of state.sessions.values()){const index=state.slots.indexOf(s.id);s.pane.classList.toggle('active',index>=0);s.pane.style.order=String(index);for(const key of ['left','top','width','height'])s.pane.style[key]='';s.pane.dataset.slot=String(index);if(index>=0){const grip=el('span','pane-drag-grip','⠿');makeTerminalDraggable(grip,s.id);s.heading.replaceChildren(grip,slotSelect(index,s.id),button('×','pane-close',()=>closeSession(s.id)));}}for(let i=0;i<state.layout;i++){if(!state.slots[i]){const empty=el('div','empty-terminal');empty.style.order=String(i);empty.dataset.slot=String(i);makeTerminalDropTarget(empty,()=>i);empty.append(slotSelect(i,null),el('p',null,'Open another host to fill this column.'),button('＋ Open a host','subtle',()=>{state.focusSlot=i;state.view='hosts';render();}));$('terminal-panes').append(empty);}}renderAllTabs();if(state.dockTree){const rects=dockRects(state.dockTree);for(let i=0;i<rects.length;i++){const p=$('terminal-panes').querySelector(`[data-slot="${i}"]`);if(p){const r=rects[i];Object.assign(p.style,{left:`calc(${r.x}% + 3px)`,top:`calc(${r.y}% + 3px)`,width:`calc(${r.w}% - 6px)`,height:`calc(${r.h}% - 6px)`});}}}if(!state.slots.includes(state.active))state.active=state.slots.find(Boolean);focusPane(state.active,false);requestAnimationFrame(()=>{if(state.locked||state.activePicker||$('sessions').hidden)return;fitVisible();state.sessions.get(state.active)?.term.focus();});}
function clipboardEnabled(){return !state.locked&&state.data?.settings?.terminalClipboard?.enabled!==false;}
function installTerminalClipboard(session){
 const current=()=>clipboardEnabled()&&!session.closed&&state.sessions.get(session.id)===session&&!$('sessions').hidden&&session.pane.classList.contains('active')&&!document.querySelector('dialog[open]');
 session.term.onSelectionChange(()=>{if(!current())return;const text=session.term.getSelection();if(text)call('terminal:copy',{id:session.id,text}).catch(error=>{if(current())notify(error.message);});});
 session.content.addEventListener('mousedown',event=>{if(event.button===2&&current()){event.preventDefault();event.stopImmediatePropagation();}},true);
 session.content.addEventListener('contextmenu',event=>{if(!current())return;event.preventDefault();event.stopImmediatePropagation();hideTerminalMenu();focusPane(session.id);const epoch=state.epoch;call('terminal:paste',{id:session.id}).then(result=>{if(current()&&epoch===state.epoch&&typeof result?.text==='string'&&result.text)session.term.paste(result.text);}).catch(error=>{if(current())notify(error.message);});},true);
}
async function connect(host,pickerId=null) {
 saveWorkspace();const epoch=state.epoch;state.activePicker=null;$('host-picker').hidden=true;$('terminal-tools').hidden=false;$('terminal-panes').hidden=false;terminalMode();
 const term=new Terminal({theme:window.LocalTermThemes.resolve(host.terminalTheme),fontFamily:'Menlo, Monaco, Consolas, monospace',fontSize:13,cursorBlink:true,scrollback:10000});const fit=new FitAddon.FitAddon();term.loadAddon(fit);const pane=el('div','terminal-pane active connecting');const heading=el('div','pane-heading');heading.append(el('span',null,`Connecting to ${host.label}…`));const content=el('div','terminal-content');pane.style.backgroundColor=content.style.backgroundColor=window.LocalTermThemes.resolve(host.terminalTheme).background;// FitAddon measures xterm's parent. Keep the visual padding outside that parent.
 const mount=el('div','terminal-mount');content.append(mount);pane.append(heading,content);$('terminal-panes').append(pane);const replaced=state.sessions.get(state.slots[state.focusSlot]);replaced?.pane.classList.remove('active');pane.style.order=String(state.focusSlot);$('terminal-panes').querySelectorAll('.empty-terminal').forEach(p=>p.remove());term.open(mount);fit.fit();term.writeln('Connecting…');
 let result;try{result=await call('ssh:connect',{hostId:host.id,cols:term.cols,rows:term.rows});}catch(e){term.dispose();pane.remove();if(!state.locked){if(pickerId&&state.pickerTabs.has(pickerId))showHostPicker(pickerId);else if(state.sessions.size)renderTerminals();else render();}throw e;}
 if(state.locked||epoch!==state.epoch||(pickerId&&!state.pickerTabs.has(pickerId))){await call('ssh:close',{id:result.id}).catch(()=>{});term.dispose();pane.remove();if(!state.locked){if(state.activePicker)showHostPicker(state.activePicker);else if(state.sessions.size)renderTerminals();else render();}return;}
 if(pickerId)state.pickerTabs.delete(pickerId);pane.classList.remove('connecting');const session={id:result.id,term,fit,pane,heading,content,host,closed:false};terminalMenu(heading,()=>session.id);state.sessions.set(result.id,session);applySessionTheme(session);installTerminalClipboard(session);makeTerminalDropTarget(pane,()=>state.slots.indexOf(session.id));pane.addEventListener('pointerdown',()=>focusPane(session.id,false));pane.addEventListener('focusin',()=>focusPane(session.id,false));term.onData(data=>{if(!session.closed)call('ssh:data',{id:session.id,data}).catch(e=>notify(e.message));});const observer = new ResizeObserver(() => {
  if (state.locked || $('sessions').hidden || $('terminal-panes').hidden || !pane.classList.contains('active')) return;
  const {cols, rows} = term;
  fit.fit();
  if (!session.closed && (cols !== term.cols || rows !== term.rows)) {
   call('ssh:resize', {id: session.id, cols: term.cols, rows: term.rows}).catch(() => {});
  }
 });
 observer.observe(mount);
 session.unobserve = () => observer.disconnect();
 try{await call('ssh:start',{id:session.id});}catch(error){session.closed=true;await closeSession(session.id);if(!state.locked&&!/Session is closed/.test(error.message))throw error;return;}if(state.locked||state.sessions.get(session.id)!==session)return;saveWorkspace();singleSession(session.id);renderTerminals();
}
function updateReturnButton(){const button=$('return-session-top');button.hidden=state.locked||!state.sessions.size;button.textContent=`›_ Return to session (${state.sessions.size}) · ${shortcutLabel}R`;button.title=state.sessions.get(state.active)?.host.label||'Return to the last terminal';}
function returnToSession(){if(state.locked||!state.sessions.size||document.querySelector('dialog[open]'))return;const id=state.sessions.has(state.active)?state.active:state.sessions.keys().next().value;showSession(id);}
function showSession(id){if(!state.sessions.has(id))return;saveWorkspace();const group=[...state.workspaces.entries()].find(([,g])=>g.slots.includes(id));if(group){showWorkspace(group[0]);focusPane(id);return;}singleSession(id);renderTerminals();}

function forwardDescription(rule){const host=state.data.hosts.find(h=>h.id===rule.hostId);const endpoint=`${rule.bindAddress}:${rule.bindPort}`;return rule.type==='dynamic'?`SOCKS5 ${endpoint} · via ${host?.label||'Missing host'}`:`${rule.type==='remote'?'Remote':'Local'} ${endpoint} → ${rule.targetAddress}:${rule.targetPort} · via ${host?.label||'Missing host'}`;}
function forwardCard(rule){
 const card=el('article','card compact-card forward-card');
 const status=state.forwards.get(rule.id);
 const top=el('div','card-top');
 const meta=el('div');
 const title=el('h3',null,rule.label);
 title.title=rule.label;
 const route=forwardDescription(rule);
 const description=el('div','address',route);
 description.title=route;
 const badge=el('span',`forward-state ${status?.status||'stopped'}`,status?.status==='running'?`● Running · port ${status.bindPort||rule.bindPort}`:status?.status==='starting'?'◌ Connecting…':status?.status==='error'?`● ${status.message||'Tunnel error'}`:'○ Stopped');
 badge.title=badge.textContent;
 meta.append(title,description);
 top.append(el('div','host-icon','⇄'),meta);
 card.append(top);
 const actions=el('div','card-actions');
 const running=['running','starting'].includes(status?.status);
 const start=button(running?'Stop':'Start','connect',()=>toggleForward(rule));
 start.disabled=status?.status==='starting';
 actions.append(start,badge,button('Edit','subtle',()=>editItem(rule,'forwards')),button('Delete','subtle',()=>deleteItem(rule,'forwards')));
 card.append(actions);
 return card;
}
function updateForwardStatus(payload){if(state.locked)return;if(payload.status==='stopped')state.forwards.delete(payload.ruleId);else state.forwards.set(payload.ruleId,payload);if(state.view==='forwards'&&!$('library').hidden)render();}
async function refreshForwards(){try{const items=await call('forward:list');if(state.locked)return;state.forwards=new Map(items.map(item=>[item.ruleId,item]));if(state.view==='forwards'&&!$('library').hidden)render();}catch(e){notify(e.message);}}
async function toggleForward(rule){const status=state.forwards.get(rule.id);if(status&&['running','starting'].includes(status.status)){await call('forward:stop',{ruleId:rule.id});state.forwards.delete(rule.id);}else{const epoch=state.epoch;state.forwards.set(rule.id,{ruleId:rule.id,status:'starting'});render();try{const result=await call('forward:start',{ruleId:rule.id});if(state.locked||epoch!==state.epoch)return;state.forwards.set(rule.id,result);}catch(e){if(!state.locked&&epoch===state.epoch)state.forwards.set(rule.id,{status:'error',message:e.message});if(!state.locked)render();throw e;}}if(!state.locked)render();}
function editForwardFields(fields,item){if(!state.data.hosts.length){fields.append(el('p','muted','Add an SSH host before creating a forwarding rule.'));}const hostLabel=el('label',null,'SSH host');const host=el('select');host.name='hostId';host.required=true;for(const h of state.data.hosts){const option=el('option',null,h.label);option.value=h.id;host.append(option);}host.value=item?.hostId||state.data.hosts[0]?.id||'';hostLabel.append(host);fields.append(hostLabel);const type=el('input');type.type='hidden';type.name='type';type.value=item?.type||'local';fields.append(type);const choices=el('div','forward-types');const help=el('p','forward-help');const bindLabel=el('div');bindLabel.append(field('bindAddress','Listening address',item?.bindAddress||'127.0.0.1','text',true),field('bindPort','Listening port',item?.bindPort||'','number',true));const target=el('div','forward-target');target.append(field('targetAddress','Destination address',item?.targetAddress||'127.0.0.1','text',true),field('targetPort','Destination port',item?.targetPort||'','number',true));const descriptions={local:'Local: listen on this computer and reach a destination through the SSH server.',remote:'Remote: listen on the SSH server and forward incoming connections to a destination reachable from this computer.',dynamic:'Dynamic: create a local SOCKS5 proxy. Configure your application to use this listening address and port.'};function choose(value){type.value=value;for(const b of choices.children)b.classList.toggle('selected',b.dataset.type===value);help.textContent=descriptions[value];target.hidden=value==='dynamic';target.querySelectorAll('input').forEach(input=>{input.disabled=value==='dynamic';input.required=value!=='dynamic';});}for(const value of ['local','remote','dynamic']){const b=button(value[0].toUpperCase()+value.slice(1),'',()=>choose(value));b.dataset.type=value;choices.append(b);}fields.append(choices,help,bindLabel,target);choose(type.value);}
async function runSnippet(snippet){const session=state.sessions.get(state.active);if(!session||session.closed)throw new Error('Connect to a host before running a snippet.');if(!confirm(`Run this command on ${session.host.label}?\n\n${snippet.command}`))return;await call('ssh:data',{id:session.id,data:snippet.command+'\n'});showSession(session.id);}
async function listFiles(){const session=state.sessions.get(state.active);if(!session||session.closed)throw new Error('Connect to a host first.');const path=$('remote-path').value||'.';const result=await call('sftp:list',{id:session.id,path});const items=Array.isArray(result)?result:result.entries||[];$('file-list').replaceChildren();const parent=button('↑ Parent directory','subtle wide',()=>{const parts=path.replace(/\/$/,'').split('/');parts.pop();$('remote-path').value=parts.join('/')||'/';return listFiles();});$('file-list').append(parent);items.filter(i=>i.name!=='.'&&i.name!=='..').sort((a,b)=>a.name.localeCompare(b.name)).forEach(file=>{const row=el('div','file-row');const directory=file.type==='directory'||file.type==='d';const full=path.replace(/\/$/,'')+'/'+file.name;row.append(el('span',null,directory?'▣':'▤'),el('span','filename',file.name),el('span','filesize',directory?'':formatBytes(file.size)));row.append(button(directory?'Open':'Download','subtle',async()=>{if(directory){$('remote-path').value=full;await listFiles();}else await call('sftp:download',{id:session.id,path:full});}));$('file-list').append(row);});}
function formatBytes(n){return Number(n)<1024?`${n||0} B`:Number(n)<1048576?`${(n/1024).toFixed(1)} KB`:`${(n/1048576).toFixed(1)} MB`;}
$('unlock-form').addEventListener('submit',action(async event=>{event.preventDefault();const password=$('vault-password').value;const method=state.path?'vault:unlock':'vault:open';applyVault(await call(method,{password}));}));
$('choose-vault').addEventListener('click',action(async()=>applyVault(await call('vault:open'))));
$('create-vault').addEventListener('click',()=>{$('create-password').value='';$('create-confirm').value='';$('create-dialog').showModal();$('create-password').focus();});
for(const id of ['close-create','cancel-create'])$(id).addEventListener('click',()=>{$('create-dialog').close();$('create-password').value='';$('create-confirm').value='';});
$('create-dialog').addEventListener('close',()=>{$('create-password').value='';$('create-confirm').value='';});
$('create-form').addEventListener('submit',action(async event=>{event.preventDefault();const password=$('create-password').value;if(password!==$('create-confirm').value)throw new Error('The passwords do not match.');const result=await call('vault:create',{password});if(result&&!result.canceled&&!result.cancelled){$('create-dialog').close();applyVault(result);}}));
$('lock').addEventListener('click',action(async()=>{await call('vault:lock');applyVault({locked:true,path:state.path});}));
$('add-item').addEventListener('click',action(()=>editItem()));$('search').addEventListener('input',render);document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>switchView(b.dataset.view)));
for(const id of ['close-editor','cancel-editor'])$(id).addEventListener('click',()=>{$('editor').close();$('editor-fields').replaceChildren();});
function updateLockControls(){for(const id of ['auto-lock-minutes','auto-lock-screen','auto-lock-suspend'])$(id).disabled=!$('auto-lock-enabled').checked;}
$('auto-lock-enabled').addEventListener('change',updateLockControls);
$('auto-lock-form').addEventListener('submit',action(async event=>{event.preventDefault();const idleMinutes=Number($('auto-lock-minutes').value);if(!Number.isInteger(idleMinutes)||idleMinutes<1||idleMinutes>1440)throw Error('Choose a timeout between 1 and 1440 minutes.');const data=structuredClone(state.data);data.settings ||= {};data.settings.autoLock={enabled:$('auto-lock-enabled').checked,idleMinutes,onScreenLock:$('auto-lock-screen').checked,onSuspend:$('auto-lock-suspend').checked};$('save-auto-lock').disabled=true;try{await save(data);notify('Automatic locking settings saved.',true);}finally{$('save-auto-lock').disabled=false;}}));
$('vault-menu').addEventListener('click',()=>{const settings={enabled:true,idleMinutes:15,onScreenLock:true,onSuspend:true,...state.data?.settings?.autoLock};$('auto-lock-enabled').checked=settings.enabled;$('auto-lock-minutes').value=settings.idleMinutes;$('auto-lock-screen').checked=settings.onScreenLock;$('auto-lock-suspend').checked=settings.onSuspend;updateLockControls();$('terminal-log-lines').value=state.data?.settings?.terminalLogLines||2000;$('terminal-clipboard-enabled').checked=state.data?.settings?.terminalClipboard?.enabled!==false;$('settings-path').textContent=state.path;$('settings').showModal();});$('close-settings').addEventListener('click',()=>$('settings').close());
$('terminal-clipboard-form').addEventListener('submit',action(async event=>{event.preventDefault();const data=structuredClone(state.data);data.settings ||= {};data.settings.terminalClipboard={enabled:$('terminal-clipboard-enabled').checked};$('save-terminal-clipboard').disabled=true;try{await save(data);notify('Terminal clipboard settings saved.',true);}finally{$('save-terminal-clipboard').disabled=false;}}));
$('save-copy').addEventListener('click',action(async()=>{const result=await call('vault:saveAs');if(result?.path){state.path=result.path;$('vault-path').textContent=state.path;$('settings-path').textContent=state.path;}if(result&&!result.canceled&&!result.cancelled)notify('Encrypted vault copy saved.',true);}));
$('open-another').addEventListener('click',action(async()=>{if(state.sessions.size&&!confirm('Opening another vault will close your active sessions. Continue?'))return;const result=await call('vault:open');if(result&&!result.canceled&&!result.cancelled){$('settings').close();closeSessions();applyVault(result);}}));
$('password-form').addEventListener('submit',action(async event=>{event.preventDefault();await call('vault:password',{password:$('new-password').value});$('new-password').value='';notify('Vault password changed.',true);}));
$('back-library').addEventListener('click',render);$('terminal-layout').addEventListener('change',e=>setLayout(e.target.value));$('terminal-lock').addEventListener('click',action(async()=>{for(const session of state.sessions.values())await persistTerminalLog(session);await call('vault:lock');applyVault({locked:true,path:state.path});}));$('files-button').addEventListener('click',action(async()=>{$('remote-path').value='.';await listFiles();$('files').showModal();}));$('close-files').addEventListener('click',()=>$('files').close());$('remote-path-form').addEventListener('submit',action(async event=>{event.preventDefault();await listFiles();}));$('upload-file').addEventListener('click',action(async()=>{await call('sftp:upload',{id:state.active,path:$('remote-path').value||'.'});await listFiles();}));
$('return-session-top').addEventListener('click',returnToSession);
window.api.on('session:return',returnToSession);
window.api.on('forward:status',updateForwardStatus);
window.api.on('ssh:data',payload=>{const session=state.sessions.get(payload.id);if(session)session.term.write(payload.data,()=>scheduleTerminalLog(session));});window.api.on('ssh:error',payload=>{const session=state.sessions.get(payload.id);session?.term.writeln('\r\n\x1b[31m'+String(payload.message).replace(/[\x00-\x1f\x7f]/g,'')+'\x1b[0m');notify(payload.message);});window.api.on('ssh:closed',payload=>{const session=state.sessions.get(payload.id);if(!session)return;session.closed=true;if(!session.closing)handleSessionClosed(payload.id).catch(error=>notify(error.message));});window.api.on('vault:locked',()=>applyVault({locked:true,path:state.path}));
call('vault:state').then(applyVault).catch(e=>notify(e.message));

document.addEventListener('keydown',event=>{if(event.key==='Escape')clearTerminalDrag();});
window.addEventListener('blur',()=>{pointerTerminalDrag=null;clearTerminalDrag();});

let pointerTerminalDrag=null,dragTabHoverTimer=null,dragTabHoverKey=null,suppressDragClickUntil=0;
function tabDropTarget(hit,event){const tab=hit?.closest('#terminal-tabs [data-tab-key]');return tab?{key:tab.dataset.tabKey,side:event.clientX<tab.getBoundingClientRect().left+tab.getBoundingClientRect().width/2?'before':'after',tab}:null;}
function reorderTerminalTab(source,target,side){if(!source||source===target)return;const order=state.tabOrder.filter(key=>key!==source),index=order.indexOf(target);if(index<0)return;order.splice(index+(side==='after'?1:0),0,source);state.tabOrder=order;}
function hoverDragTab(tab){
 const key=tab?.dataset.workspace?`workspace:${tab.dataset.workspace}`:tab?.dataset.session?`session:${tab.dataset.session}`:null;
 if(key===dragTabHoverKey)return;
 clearTimeout(dragTabHoverTimer);dragTabHoverTimer=null;dragTabHoverKey=key;
 if(!key)return;
 const workspace=tab.dataset.workspace,id=tab.dataset.session;
 if(workspace===state.activeWorkspace||id===state.active||id===state.dragSession)return;
 dragTabHoverTimer=setTimeout(()=>{dragTabHoverTimer=null;if(!pointerTerminalDrag?.started||state.locked||dragTabHoverKey!==key)return;if(workspace)showWorkspace(workspace);else showSession(id);},350);
}
document.addEventListener('click',event=>{if(pointerTerminalDrag?.started||(event.detail>0&&performance.now()<suppressDragClickUntil)){suppressDragClickUntil=0;event.preventDefault();event.stopImmediatePropagation();}},{capture:true});
document.addEventListener('pointermove',event=>{
 const drag=pointerTerminalDrag;if(!drag||state.locked)return;
 if(!drag.started){if(Math.hypot(event.clientX-drag.x,event.clientY-drag.y)<6)return;drag.started=true;state.dragSession=drag.id;document.body.classList.add('terminal-dragging');}
 event.preventDefault();const hit=document.elementFromPoint(event.clientX,event.clientY),pane=hit?.closest('.terminal-pane.active,.empty-terminal');
 document.querySelectorAll('[data-drop-zone]').forEach(p=>{if(p!==pane)delete p.dataset.dropZone;});
 document.querySelectorAll('[data-tab-drop]').forEach(tab=>delete tab.dataset.tabDrop);
 const target=drag.tabKey?tabDropTarget(hit,event):null;if(target&&target.key!==drag.tabKey)target.tab.dataset.tabDrop=target.side;
 hoverDragTab(pane?null:drag.tabKey?(drag.id?hit?.closest('[data-workspace]'):null):hit?.closest('[data-workspace],[data-session]'));
 if(pane)pane.dataset.dropZone=dropZone(event,pane);
},{passive:false});
document.addEventListener('pointerup',event=>{
 const drag=pointerTerminalDrag;if(!drag?.started){clearTerminalDrag();return;}
 event.preventDefault();suppressDragClickUntil=performance.now()+250;
 const hit=document.elementFromPoint(event.clientX,event.clientY),target=drag.tabKey?tabDropTarget(hit,event):null;
 const pane=hit?.closest('.terminal-pane.active,.empty-terminal');
 const index=pane?Number(pane.dataset.slot):-1,zone=pane?dropZone(event,pane):null;
 clearTerminalDrag();if(!state.locked&&target)reorderTerminalTab(drag.tabKey,target.key,target.side);
 if(!state.locked&&state.sessions.has(drag.id)&&index>=0&&zone)dockSession(drag.id,index,zone);
 if(!state.locked)renderAllTabs();
});
document.addEventListener('pointercancel',()=>{const dragging=pointerTerminalDrag?.started;clearTerminalDrag();if(dragging){suppressDragClickUntil=performance.now()+250;if(!state.locked)renderAllTabs();}});

function renderAllTabs(){
 if(pointerTerminalDrag?.started)return; // Keep the grabbed tab mounted until release.
 const tabs=$('terminal-tabs');tabs.replaceChildren();
 const grouped=new Set();
 for(const [key,g] of state.workspaces){g.slots.forEach(id=>grouped.add(id));const tab=button(`▦ Workspace · ${g.slots.length}`,!state.activePicker&&state.activeWorkspace===key?'active':'',()=>showWorkspace(key));tab.dataset.workspace=key;tab.dataset.tabKey='workspace:'+key;makeTerminalDraggable(tab,null);terminalMenu(tab,()=>g.active||g.slots.find(id=>state.sessions.has(id)));tab.title=g.slots.map(id=>state.sessions.get(id)?.host.label).join(' · ');const close=el('span',null,'×');close.title='Close workspace';close.addEventListener('click',action(async e=>{e.stopPropagation();for(const id of [...g.slots])await closeSession(id);}));tab.append(close);tabs.append(tab);

 }
 for(const s of state.sessions.values()){
  if(grouped.has(s.id))continue;
  const tab=button(`${s.closed?'○':'●'} ${s.host.label}`,!state.activePicker&&s.id===state.active?'active':'',()=>showSession(s.id));tab.dataset.session=s.id;tab.dataset.tabKey='session:'+s.id;terminalMenu(tab,()=>s.id);makeTerminalDraggable(tab,s.id);
  const close=el('span',null,'×');close.title='Close session';close.addEventListener('click',action(async e=>{e.stopPropagation();const picker=state.activePicker;await closeSession(s.id);if(picker&&state.pickerTabs.has(picker))showHostPicker(picker);}));tab.append(close);tabs.append(tab);
 }
 for(const [id] of state.pickerTabs){const tab=button('New Tab',state.activePicker===id?'active':'',()=>showHostPicker(id));tab.dataset.picker=id;tab.dataset.tabKey='picker:'+id;makeTerminalDraggable(tab,null);const close=el('span',null,'×');close.title='Close new tab';close.addEventListener('click',e=>{e.stopPropagation();closeHostPicker(id);});tab.append(close);tabs.append(tab);}
 const current=[...tabs.children],keys=new Set(current.map(tab=>tab.dataset.tabKey));state.tabOrder=state.tabOrder.filter(key=>keys.has(key));for(const tab of current)if(!state.tabOrder.includes(tab.dataset.tabKey))state.tabOrder.push(tab.dataset.tabKey);const byKey=new Map(current.map(tab=>[tab.dataset.tabKey,tab]));for(const key of state.tabOrder)tabs.append(byKey.get(key));
 const add=button('＋','new-terminal-tab',openHostTab);add.id='new-terminal-tab';add.title=`New tab (${shortcutLabel}T)`;add.setAttribute('aria-label','New terminal tab');tabs.append(add);
}
function openHostTab(){hideTerminalMenu();if(state.locked||document.querySelector('dialog[open]'))return;const id=crypto.randomUUID();state.pickerTabs.set(id,{query:'',connecting:false});showHostPicker(id);}
function showHostPicker(id){if(state.locked||!state.pickerTabs.has(id))return;clearTerminalDrag();state.activePicker=id;terminalMode();$('terminal-tools').hidden=true;$('terminal-panes').hidden=true;$('host-picker').hidden=false;$('host-picker-search').value=state.pickerTabs.get(id).query;renderAllTabs();renderHostChoices();$('host-picker-search').focus();}
function closeHostPicker(id){const active=state.activePicker===id;state.pickerTabs.delete(id);if(!active){renderAllTabs();return;}state.activePicker=null;const other=[...state.pickerTabs.keys()].at(-1);if(other)showHostPicker(other);else if(state.sessions.size)showSession(state.active&&state.sessions.has(state.active)?state.active:state.sessions.keys().next().value);else render();}
function pickerHosts(){const query=$('host-picker-search').value.trim().toLowerCase();return state.data.hosts.filter(h=>[h.label,h.address,h.username,h.group].filter(Boolean).join(' ').toLowerCase().includes(query));}
function renderHostChoices(){if(state.locked||!state.activePicker)return;const hosts=pickerHosts(),container=$('host-picker-results');container.replaceChildren();$('host-picker-count').textContent=`${hosts.length} ${hosts.length===1?'host':'hosts'}`;for(const host of hosts){const row=button('','picker-host',()=>choosePickerHost(host));row.append(el('span','picker-host-icon','›_'));const name=el('span','picker-host-name');name.append(el('strong',null,host.label),el('small',null,`${host.username}@${host.address}:${host.port||22}`));row.append(name,el('span','picker-host-group',host.group||'Personal'));container.append(row);}if(!hosts.length)container.append(el('p','picker-empty',state.data.hosts.length?'No matching hosts. Try a different search.':'No hosts saved yet. Add a host in Workspace.'));}
async function choosePickerHost(host){const id=state.activePicker,picker=state.pickerTabs.get(id);if(!picker||picker.connecting)return;picker.connecting=true;try{await connect(host,id);}finally{if(state.pickerTabs.has(id))picker.connecting=false;}}
$('host-picker-search').addEventListener('input',()=>{const picker=state.pickerTabs.get(state.activePicker);if(picker)picker.query=$('host-picker-search').value;renderHostChoices();});
$('host-picker-search').addEventListener('keydown',action(async event=>{if(event.key==='Enter'){event.preventDefault();const host=pickerHosts()[0];if(host)await choosePickerHost(host);}else if(event.key==='ArrowDown'){event.preventDefault();$('host-picker-results').querySelector('button')?.focus();}else if(event.key==='Escape'){event.preventDefault();closeHostPicker(state.activePicker);}}));
document.addEventListener('keydown',event=>{if(!(usesControlShortcuts?(event.ctrlKey&&!event.metaKey):(event.metaKey&&!event.ctrlKey))||event.altKey||event.shiftKey||state.locked||document.querySelector('dialog[open]'))return;if(event.key.toLowerCase()==='r'){event.preventDefault();event.stopImmediatePropagation();if(!event.repeat)returnToSession();}else if(event.key.toLowerCase()==='t'){event.preventDefault();event.stopImmediatePropagation();if(!event.repeat)openHostTab();}else if(event.key.toLowerCase()==='k'&&state.activePicker){event.preventDefault();$('host-picker-search').focus();}},true);

$('host-picker').querySelector('.picker-search>span').textContent=shortcutLabel+'K';

$('import-vault').addEventListener('click',()=>{$('settings').close();$('import-password').value='';$('import-dialog').showModal();$('import-password').focus();});
for(const id of ['close-import','cancel-import'])$(id).addEventListener('click',()=>{$('import-dialog').close();$('import-password').value='';});
$('import-dialog').addEventListener('close',()=>{$('import-password').value='';});
$('import-form').addEventListener('submit',action(async e=>{e.preventDefault();const result=await call('vault:import',{password:$('import-password').value});if(result?.canceled)return;$('import-dialog').close();applyVault(result);const s=result.importSummary;notify(`Imported ${s.hostsAdded} hosts; merged ${s.hostsMerged}; added ${s.keysAdded} keys.${s.hostsNeedingSetup?' '+s.hostsNeedingSetup+' hosts need configuration (see notes).':''}`,true);}));

let lastActivityReport=0;for(const name of ['keydown','pointerdown','pointermove','wheel'])document.addEventListener(name,event=>{if(!event.isTrusted||state.locked||Date.now()-lastActivityReport<10000)return;lastActivityReport=Date.now();call('app:activity').catch(()=>{});},{capture:true,passive:true});

const updateProgressDialog = $('update-progress');
updateProgressDialog.addEventListener('cancel', event => event.preventDefault());
window.api.on('update:progress', ({stage, percent}) => {
 if (stage === 'idle') {
  if (updateProgressDialog.open) updateProgressDialog.close();
  return;
 }
 const messages = {
  downloading: 'Downloading update…',
  verifying: 'Verifying download…',
  preparing: 'Preparing installation…',
  restarting: 'Restarting LocalTerm…'
 };
 if (!Object.hasOwn(messages, stage)) return;
 const progress = $('update-progress-bar');
 const status = $('update-progress-status');
 if (status.textContent !== messages[stage]) status.textContent = messages[stage];
 const measurable = stage === 'downloading' && Number.isFinite(percent);
 if (measurable) progress.value = percent;
 else progress.removeAttribute('value');
 $('update-progress-percent').textContent = measurable ? percent + '%' : '';
 if (!updateProgressDialog.open) updateProgressDialog.showModal();
});
$('check-updates').addEventListener('click',action(async()=>{const b=$('check-updates');b.disabled=true;b.textContent='Checking…';try{await call('update:check',{manual:true});}finally{b.disabled=false;b.textContent='Check for updates';}}));

$('terminal-workspace').onclick=render;
const logTimers=new Map();
function scheduleTerminalLog(session){if(logTimers.has(session.id))return;logTimers.set(session.id,setTimeout(()=>{logTimers.delete(session.id);persistTerminalLog(session);},3000));}
async function persistTerminalLog(session){if(!session||session.logDisabled||state.locked)return;const logEpoch=state.epoch;clearTimeout(logTimers.get(session.id));logTimers.delete(session.id);if(session.term.buffer)await new Promise(resolve=>session.term.write('',resolve));if(state.locked||logEpoch!==state.epoch)return;const b=session.term.buffer?.active;if(!b)return;const lines=[],limit=state.data.settings?.terminalLogLines||2000;for(let i=Math.max(0,b.length-limit);i<b.length;i++)lines.push(b.getLine(i)?.translateToString(true)||'');try{await call('logs:save',{id:session.id,host:session.host.label,username:session.host.username,text:lines.join('\n')});}catch(e){if(!state.locked)notify('Terminal log could not be saved: '+e.message);}}
$('terminal-logs-form').onsubmit=action(async e=>{e.preventDefault();const lines=Number($('terminal-log-lines').value);await call('logs:settings',{lines});state.data.settings ||= {};state.data.settings.terminalLogLines=lines;notify('Terminal log settings saved.',true);});
$('terminal-logs-open').onclick=action(async()=>{
 for(const session of state.sessions.values())await persistTerminalLog(session);
 const logs=await call('logs:list');
 render();
 $('library').hidden=true;
 const root=$('terminal-logs');
 root.hidden=false;
 root.replaceChildren(el('h1',null,'Terminal logs'),el('p','muted','Recent output is encrypted and stored on this computer. Select a session to view it.'));
 root.append(
   button('Restore archive…','',async()=>{
     const result=await call('logs:restore');
     if(!result.canceled){notify('Archive restored.',true);$('terminal-logs-open').click();}
   }),
   button('Archive encrypted logs…','',async()=>{
     const result=await call('logs:archive');
     if(!result.canceled)notify('Encrypted archive saved.',true);
   }),
   button('Delete all logs','',async()=>{
     if(!confirm('Permanently delete all local terminal logs?'))return;
     await call('logs:delete',{});
     for(const session of state.sessions.values())session.logDisabled=true;
     $('terminal-logs-open').click();
   })
 );
 if(!logs.length){
   root.append(el('p',null,'No terminal logs yet.'));
   return;
 }
 const list=el('div','terminal-log-list');
 const headings=el('div','terminal-log-row terminal-log-headings muted');
 const labels=el('div','terminal-log-columns');
 labels.append(el('span',null,'Date'),el('span',null,'Host'),el('span',null,'User'));
 headings.append(labels,el('span',null,'Actions'));
 list.append(headings);
 const output=el('pre');
 output.hidden=true;
 for(const log of logs){
   const date=new Date(log.updated).toLocaleString();
   const row=el('div','terminal-log-row');
   const open=button(undefined,'terminal-log-columns',()=>{
     output.textContent=log.text;
     output.hidden=false;
   });
   for(const value of [date,log.host,log.username]){
     const cell=el('span',null,value);
     cell.title=value;
     open.append(cell);
   }
   const remove=button('Delete','',async()=>{
     if(!confirm('Permanently delete this terminal log?'))return;
     await call('logs:delete',{id:log.id});
     const session=state.sessions.get(log.id);
     if(session)session.logDisabled=true;
     $('terminal-logs-open').click();
   });
   remove.setAttribute('aria-label',`Delete log for ${log.host} from ${date}`);
   row.append(open,remove);
   list.append(row);
 }
 root.append(list,output);
});
