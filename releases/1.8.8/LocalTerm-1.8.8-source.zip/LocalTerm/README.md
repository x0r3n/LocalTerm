# LocalTerm

LocalTerm is a local SSH client for macOS and Windows with a portable, password-encrypted vault. No LocalTerm account is required.

![LocalTerm hosts and groups](docs/images/localterm-hosts.jpg)

## Download

Get the macOS Apple Silicon ZIP, Windows x64 portable EXE or Windows ZIP from [Release 1.8.8](https://github.com/x0r3n/LocalTerm/releases/tag/v1.8.8). The release includes source and SHA-256 checksums. The Mac build is ad hoc signed and not notarized; Windows builds are unsigned.

See the [macOS guide](docs/macos.md) and [Windows guide](docs/windows.md) for installation, shortcuts and usage.

## Features

- Encrypted `.ltvault` for hosts, credentials, private keys, snippets, forwarding rules and settings.
- Searchable SSH tabs, draggable split workspaces, duplicate sessions and per-host terminal themes.
- Two-pane SFTP with batch upload, download and delete; overwrite, rename or skip conflicts with an apply-to-all option. Copy supports regular files; delete supports files and empty folders.
- Local, remote and dynamic SOCKS5 forwarding, ordered jump hosts and host fingerprint checks.
- Configurable vault locking, terminal clipboard behavior and manual or daily update checks.

The same vault format works on both platforms. Use a synchronized vault on one device at a time and keep backups.

## Development

```sh
npm ci
npm test
npm start
npm run build       # macOS Apple Silicon
npm run build:win   # Windows x64 ZIP and portable EXE
```

Node.js 22+ and npm are required. Large binaries in `builds/` use Git LFS; GitHub's source ZIP may contain LFS pointers. The release includes a separate source archive. The 1.8.5 test suite passed 88 tests on macOS, including local SFTP integration tests; native Windows runtime testing remains outstanding.

## License

Copyright © 2026 x0r3n. Licensed under [GPL-3.0-only](LICENSE); see [COPYRIGHT](COPYRIGHT). There is no warranty. Third-party license notices, including Electron and Chromium notices, are included in the packages. Rights granted under earlier MIT-licensed versions remain valid.

## Compact terminal bar and logs (1.8.0)

Terminals use a single top tab bar with Workspace on the left. Right-click a tab for Layout, Duplicate, Close terminal, Browse files and Lock vault. Terminal logs appears below Port forwarding in the sidebar. Select a recent session to read its output. Vault settings controls the number of lines retained per terminal (default 2000, range 100–10000). Logs are saved every few seconds in a separate encrypted file in the local application data folder. Up to 50 sessions and 4 MB of log text are retained. An unexpected shutdown may lose the last few seconds.

## Local encrypted logs (1.8.1)

Terminal logs are encrypted in the local application data folder. The encryption key is stored in the vault. Existing vault logs are migrated on first use. Delete individual or all logs, or export and restore an encrypted archive from Terminal logs. The archive requires the same vault key; retain a backup of the vault. Logs stay local to each computer.

## macOS local network access (1.8.4)

The macOS build includes a local network usage description and distinct executable UUIDs. Allow LocalTerm under Privacy & Security → Local Network when prompted. The build is ad hoc signed; it is not notarized. The local network connection was confirmed by the user.

## Tab reordering (1.8.5)

Drag a terminal tab left or right in the top tab bar and release it before or after another tab. A green insertion marker shows its destination. Workspace and new-host picker tabs can also be reordered. Connections and split layouts stay open, and the order is retained while the vault is unlocked. Dragging onto a terminal pane still creates a split; hover over a Workspace tab to reveal its panes. Press Escape to cancel.

## SSH keepalive (1.8.6)

For an SSH server that repeatedly disconnects with the default keepalive, open **Hosts → Edit**, select **SSH keepalive → Off**, then save and reconnect. The setting applies to that host, including when it is used as a jump host. The default sends a probe every 15 seconds.

## Terminal sizing and update progress (1.8.7)

Terminal panes fit full rows when resizing the window, including split layouts. After selecting **Update now**, a progress indicator shows the download percentage, verification, installation preparation, and restart.

## Terminal background (1.8.8)

The space below the last full terminal row now uses the selected theme background, including in split panes.
