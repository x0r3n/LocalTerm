# LocalTerm

A standalone desktop SSH client, with all saved connection data in one portable password-encrypted `.ltvault` file.

## Start

Open `dist/mac-arm64/LocalTerm.app`. This build is for Apple Silicon Macs and is locally built, unsigned, and not notarized.

1. Choose **Create a new vault**, enter and confirm a password of at least 12 characters, then choose a new file anywhere you can write: your disk, a removable drive, or a mounted synced folder.
2. Add private keys under **Keys**. Import copies the key contents into the encrypted vault; the original key file is not modified or deleted.
3. Add a **Host**, its address, port, username, and password or private key. Use groups to organize hosts.
4. Connect. Compare the SSH fingerprint with a trusted source before accepting a new server identity.
5. Use **Browse files** in a connected terminal for SFTP uploads, downloads, and directory browsing. **Snippets** stores reusable commands.

Use **Choose a vault file** to load an existing LocalTerm vault, then enter its password. Opening a vault edits that file in place; it does not import it into a hidden database. **Vault settings → Save an encrypted copy as…** creates a portable copy and keeps the original file active. Open the copy explicitly to work from it. Select the file again after restarting the app.

Keep backups and remember the password: there is no recovery service. Changing the current vault password does not change passwords on older copies. A synced folder is managed by your own sync provider; avoid editing the same vault on two computers at once. External changes detected before saving cause a refusal instead of an overwrite. This is not a distributed locking or merge protocol.

## Included

- **⌘T** opens a new host-picker tab while preserving existing terminals. The **＋** button does the same. Search by host name, address, username, or group; press **Enter** to connect to the first result or click a host. **⌘K** focuses search and **Escape** closes the picker. Each new tab keeps its own search until connected or closed.

- Host, group, credential, private key, and snippet management.
- Password and private-key SSH authentication; multiple terminal tabs and resizing.
- Drag tabs or a pane’s dotted grip onto another pane: left/right/top/bottom edges create a split, center swaps or replaces a session. A green preview marks the drop area. Mixed horizontal/vertical arrangements support up to six terminals. Press Escape to cancel. The Layout menu restores equal columns.
- Compact host cards with smaller icons keep the host library dense and easy to scan.
- Single, two-column, and three-column terminal layouts, with per-column session selection and independent input. Opening a host hides the sidebar/header/footer; **Workspace** restores them. Select **Layout → 2 columns / 3 columns** in the terminal toolbar.
- Local, Remote, and Dynamic (SOCKS5 CONNECT) port forwarding, saved in the encrypted vault. Choose **Port forwarding → New forwarding rule**, select the SSH host and type, enter listening address/port and (for Local/Remote) destination address/port, then save and press **Start**. Tunnels use independent SSH connections and do not need a terminal. **Stop**, closing the app, or locking the vault closes the tunnel and its connections. Editing an active rule stops it; restart it after saving.
- Local destinations are reached from the SSH server; Remote destinations are reached from this computer. Dynamic mode is a local SOCKS5 proxy whose destinations are resolved by the SSH server. The default listening address is `127.0.0.1`. The SSH server must permit forwarding; Remote binding is also governed by its `GatewayPorts` policy.
- SFTP browsing, upload, and download, with confirmation before replacing a remote file.
- Encrypted trusted host fingerprints; changed fingerprints block connections. After independently verifying an intentional key change, use the host editor's **Forget saved SSH fingerprint** button.
- Vault settings offers an automatic locking master switch, a 1–1440 minute inactivity timeout, and separate screen-lock/sleep switches. Defaults remain enabled with a 15-minute timeout. Disabling the master switch suppresses all automatic locking. Manual lock and app exit still lock the vault. Settings are saved in the encrypted vault.
- Password changes and encrypted vault copies, native file pickers, external-edit detection, and atomic file replacement.

## Encryption and storage

The entire saved collection—hostnames, usernames, passwords, private key contents, key passphrases, snippets, settings, and trusted host fingerprints—is encrypted with AES-256-GCM. A 256-bit key is derived from the vault password with scrypt (`N=65536, r=8, p=1`) and a random 32-byte salt. Each save uses a new random 12-byte nonce and a 16-byte authentication tag. Format version and KDF parameters are stored in the unencrypted file header. No vault password is saved. Data is decrypted in memory while unlocked.

Encrypted writes use a temporary file with owner-only permissions followed by rename. The app creates no plaintext key files, credential database, account, cloud sync service, or telemetry. Electron may create ordinary runtime/cache files in the user's application support directory. SFTP downloads are ordinary files deliberately saved to the location you select, and upload contents go to the selected SSH server. Original imported private-key files remain wherever they already existed. Memory clearing in a JavaScript runtime cannot guarantee erasure of every historical string copy or OS swap.

## Scope

The application does not currently include Mosh, serial connections, SSH agent/FIDO2 integration, keyboard-interactive MFA or team sharing. **Choose a vault file** loads LocalTerm vaults; encrypted vault import merges LocalTerm files. The implementation has automated tests but has not received an independent security audit.

## Source and verification

From this folder, with Node.js and npm installed:

```sh
npm ci
npm test
npm start
npm run build
```

The checked-in lockfile pins dependencies. Fifty-five tests cover encrypted portable round trips, wrong-password and tamper rejection, password rotation, external-edit detection, malicious KDF headers, safe UI rendering and sensitive-field clearing, pending-connection locking, and a local SSH server exercising password/key login, UTF-8 streaming, SFTP listing, and changed-host-key rejection. Additional coverage exercises two/three-column session focus/input/resize, all three tunnel types with real TCP traffic, fragmented SOCKS5 handshakes, invalid proxy requests, port conflicts, stop/lock cleanup, and encrypted forwarding rules with old-vault compatibility. The SSH integration test mocks only Electron window/dialog services; it uses the actual SSH client/server transport.

The packaged app was also opened on this Mac, an encrypted synthetic vault loaded and unlocked through the native file picker, its host library inspected, and the vault locked again. The 1.1.0 build was additionally verified with three simultaneous SSH terminals against a local synthetic test server, automatic sidebar hiding/restoration, and native SOCKS5 Start/Stop controls. The 1.2.0 build was also verified with actual mouse drags from a terminal tab to a right-edge split and then a bottom-edge split, plus visual inspection of the compact host cards. Synthetic servers and credentials were used during verification.

The 1.3.0 build was verified on this Mac with the native ⌘T shortcut and live host-search filtering using a synthetic encrypted vault. The UI tests also cover connecting from the picker, multiple independent picker tabs, closing and locking, and retrying failed connections without closing existing terminals.

## Windows 1.5.4 build

Build Windows x64 artifacts with `npm run build:win`. The target produces a ZIP directory distribution and a standalone portable executable; no Windows installer is included. Windows uses Ctrl+T / Ctrl+K and the same encrypted vault format as macOS. Optional native `.node` addons are excluded from Windows packages, and ssh2 uses its portable implementation. Windows resource editing and code signing are disabled for this cross-build.

The complete suite of 55 tests passes on macOS, including when loading optional native addons is disabled. Windows artifacts receive PE architecture, ZIP integrity and packaged-source/ASAR checks. No Windows runtime or VM is available in this task, so Windows execution, OS lock events, filesystem permissions and networking still need verification on Windows.

## Encrypted vault import (1.4.0)

Vault settings now offers **Import from another encrypted vault**. Enter the source password and choose a `.ltvault` file. The current vault receives an encrypted sibling backup before merging. Existing hosts, credentials, snippets and trusted fingerprints are preserved. Import deduplicates source IDs, keys by private-key material, and unambiguous endpoint matches, while keeping separately named source entries. Imported hosts without a username remain visible for editing. Unsupported jump-host/proxy/hardware-auth requirements remain marked and block direct SSH connections until those requirements are migrated.

Magyar használati útmutatók: `LocalTerm-macOS-README.txt` és `LocalTerm-Windows-README.txt` a kiadási csomagok mellett.

## Return to session (1.4.1)

The Workspace header now includes a Return to session button outside the scrolling host list. Cmd+R on macOS and Ctrl+R on Windows return to the last focused terminal and preserve split layouts. Electron intercepts the accelerator before its Reload menu action. Locked vaults and open dialogs do not navigate.

The 1.4.1 return accelerator and header button were also verified in an isolated native Mac app with a real local SSH connection, preserving terminal contents. The live user instance was left running.

## Closing split terminals (1.4.4)

Closing a visible terminal removes its split and expands the remaining panels. A single visible survivor fills the terminal area, including after nested mouse-created layouts. Hidden tabs remain available without being pulled into the closed pane.

Workspace tabs (1.4.4): split terminals share one Workspace tab. New host connections open separately at full size. Switch back to restore the split. Drag a separate tab over the Workspace tab, then onto a pane edge to add it. Closing panes collapses the split. Workspace layouts last for the current unlocked session.

Drag fix (1.4.4): tab elements stay mounted during a drag, hovering a target tab for 350ms switches to it, and the release click is consumed to preserve the drop result.

The 1.4.4 drag fix was verified in the isolated native Mac app using actual mouse drags: an inactive tab into a right split, then a third standalone tab into a bottom split within the restored Workspace. The production app and vault were left untouched.

## Jump hosts (1.5.0)

Save each bastion as a normal host, then edit the destination's **Jump hosts (in connection order)** list and save. Each hop uses its own stored username/password/private key and host-key verification. A hop's own jump route is resolved first. At most eight SSH hosts including the destination are allowed; missing references, duplicate selections, and cycles are rejected. Remove references before deleting an in-use jump host.

Connections use SSH direct-tcpip streams, so destination names are resolved on the preceding SSH server. Terminal, SFTP, Local/Remote/SOCKS5 forwarding share this transport. Closing or locking destroys the complete chain, including pending handshakes and trust prompts. Changing host records stops existing forwarding rules so they can be restarted with the new route.

Routes are stored in the encrypted vault as `jumpHostIds`. Existing direct-host vaults remain compatible. Use version 1.5.0 or newer when editing vaults with jump routes. The editor proposes imported source references where they can be resolved; review and save them to clear only the jump-specific migration blocker. Import remaps route references when IDs collide.

Validation includes a two-hop IPC terminal/SFTP connection with password/key authentication, per-hop trust and changed-identity rejection, lock during a pending trust decision, real traffic through all three forwarding types over a jump, encrypted route round trips, graph validation and editor/import tests. The isolated native Mac preview also saved and connected to a synthetic private destination through a bastion. Windows execution remains untested.

## Remembered vault and searchable jump selector (1.5.1)

The last successfully opened/created vault path is stored in `preferences.json` in Electron's user-data directory. A restart restores the path while keeping the vault locked and requiring its password. Failed unlocks, canceled pickers, imports and saving a copy do not replace the last working path. A missing or offline vault keeps its remembered path; the user can choose another file. Preferences contain only the path and are written atomically with restrictive permissions. Corrupt/missing preferences fall back to the file picker. A preference-write failure still opens the vault and reports that the path could not be remembered.

The jump-host picker sorts available hosts alphabetically and filters by name, address, username or group. Searching and sorting do not change the chosen connection order. Restart tests exercise real encrypted vaults and ensure unlocking needs no picker; UI coverage checks sorted choices, search, empty results and preserved route ordering.

Native Mac QA for 1.5.1 confirmed alphabetically ordered jump-host options, filtering by group, and a full quit/relaunch restoring the synthetic vault path on the locked welcome screen with an empty password field. The production instance and vault were left untouched.

## Session exit and Duplicate (1.5.2)

An SSH close event removes the terminal pane/tab, collapses its split and disposes its terminal/resize observer. The final close returns to the host library. Background closes preserve the library or host picker being used. Manual-close/server-close races are idempotent and do not send duplicate close requests.

Right-click a terminal tab and choose Duplicate for an independent SSH login to that saved host using its current vault credentials and jump route. The original remains connected; the new session opens as a separate full-size tab. Workspace tabs duplicate their last focused member; pane headings offer the same action for a specific member. The remote shell process/directory is not cloned. Escape, outside clicks and locking dismiss the menu.

Tests exercise real SSH exit/Ctrl+D close notifications, auto-collapse, background-view preservation, close races, independent duplication, Workspace member selection and menu dismissal.

Native Mac QA for 1.5.2 used a right-click on a live synthetic SSH tab, Duplicate, a two-column split, typing exit to close one pane and auto-expand its survivor, then actual Ctrl+D to close the final pane and return to the host library. The production app and vault were left untouched.

## Host search focus (1.5.3)

Opening Hosts immediately focuses Search hosts, including when Hosts was already selected. Initial vault unlock, returning from a terminal and selecting a host group also focus the host search. Typing rerenders do not reset the caret, and open dialogs keep their own focus.

Native Mac QA for 1.5.3 confirmed search focus after vault unlock and navigating Keys → Hosts, followed by typing Staging without clicking the search input and seeing the filtered host. All 31 existing UI tests passed; the change is confined to renderer focus handling.

## Automatic locking controls (1.5.4)

Vault settings → Automatic vault locking controls inactivity, screen lock and sleep. Save locking settings applies the policy immediately and keeps it across vault reopen. Keyboard and pointer activity count as app activity; background terminal output does not reset the timer. Manual locking and quitting still close sessions and clear the unlocked vault.

## Licenc

Copyright © 2026 x0r3n. A jelenlegi LocalTerm-forráskód a **GNU General Public License 3.0** alatt érhető el, kizárólag a 3. verzió szerint (`GPL-3.0-only`). A teljes licencszöveg a [LICENSE](LICENSE) fájlban, a szerzői jogi nyilatkozat a [COPYRIGHT](COPYRIGHT) fájlban található.

A program használható, módosítható és továbbadható a GPL feltételei szerint. Továbbadáskor biztosítani kell a megfelelő forráskódhoz való hozzáférést és meg kell őrizni a szükséges jogi jelöléseket. A programra nincs garancia.

A külső függőségek saját licencei és szerzői jogi jelölései érvényben maradnak. A korábban MIT alatt kiadott források és kész 1.5.4-es csomagok MIT szerinti jogosultságait ez a változás nem vonja vissza. A repóban jelenleg letölthető 1.5.4-es csomagok GPL-licenccel újraépített változatok; a korábbi MIT-kiadásoktól az SHA-256 ellenőrzőösszegük különbözteti meg őket. A GPL és a szerzői jogi nyilatkozat az alkalmazáscsomagban is megtalálható. A pontos forrás a kész csomagok mellett, a `releases/1.5.4/LocalTerm-1.5.4-source.zip` fájlban is elérhető.

## Külső futtatókörnyezet licencértesítői

A macOS-csomagban a `LocalTerm.app/Contents/Resources/LICENSE.electron.txt` és `LICENSES.chromium.html` fájlok tartalmazzák az Electron és a Chromium értesítőit. Windowson ugyanezek a fájlnevek a kibontott alkalmazás főmappájában találhatók. A LocalTerm saját GPL-licence külön, a `Resources/LICENSE` (macOS), illetve `resources/LICENSE` (Windows) fájlban marad. A külső összetevők eredeti licencszövegei változatlanul megmaradnak.

## Terminálvágólap (1.5.5)

A terminálban kijelölt szöveg azonnal a rendszer vágólapjára kerül. Jobb kattintás a terminál tartalmán beilleszti a vágólap szövegét abba a panelbe. A fülek jobb kattintásos Duplicate menüje változatlanul használható.

A funkció alapból bekapcsolt. Kikapcsolás: **Vault settings → Terminal clipboard → Copy selection and paste on right-click**, majd **Save clipboard settings**. A választás a titkosított vaultban megmarad, és minden nyitott terminálra azonnal érvényes. A megszokott billentyűs másolás és beillesztés továbbra is használható.

A beillesztés az xterm.js normál paste útvonalát használja, beleértve a távoli alkalmazás által bekapcsolt bracketed paste módot. Zárolt vaultba vagy közben bezárt terminálba függőben lévő beillesztés nem jut el. A vágólap a rendszer vágólapja, a rámásolt szöveget a vault zárolása nem törli.

## Hostonkénti termináltémák (1.5.6)

**Hosts → Edit → Terminal theme**: minden hosthoz külön téma menthető. Választható a **Default**, a vöröses **Ember Dune**, a zöldes **Emerald** és a világos **Paper**, továbbá a **Custom** mód. Minden meglévő és új host alapértelmezése a korábbi, változatlan LocalTerm-színvilág.

Custom módban külön beállítható a háttér, a betűszín, a kurzor, a kijelölés háttere és a kijelölt szöveg színe. Színválasztó és hatjegyű hex mező is használható, élő előnézettel. A **Save changes** az adott hosttal együtt, a titkosított vaultba menti a témát. Az adott host már nyitott termináljai újracsatlakozás nélkül frissülnek, a többi host színei megmaradnak. A Default választás visszaállítja az eredeti színeket.

Az 1.5.6 kiadásnál 71 automatizált teszt sikeres macOS-en, beleértve a témák validálását, a titkosított mentést, az importot és a nyitott terminálok frissítését. A témaelőnézetet és az egyéni színek élő alkalmazását natív Mac-felületen, szintetikus SSH-kapcsolaton is ellenőriztük.

## Application updates (1.6.0)

After the first vault unlock of the day, LocalTerm checks the latest stable release at https://github.com/x0r3n/LocalTerm/releases. The check date is stored locally on this computer. Vault settings also contains **Check for updates**, which runs a check immediately.

When an update is available, choose **Update now** or **Later**. Updates are never installed automatically. LocalTerm downloads the matching macOS Apple Silicon ZIP or Windows x64 portable executable and verifies its size and SHA-256 digest against GitHub release metadata. It closes SSH connections, locks the vault, replaces the app, and restarts. The previous app is retained beside the installation with a `.previous-<timestamp>` suffix. The app must be installed in a writable location. The vault file is not moved.

Publish future releases with the existing asset names: `LocalTerm-VERSION-Mac-AppleSilicon.zip` containing LocalTerm.app and `LocalTerm-VERSION-Windows-x64-Portable.exe`. The GitHub asset must include its SHA-256 digest. Draft and prerelease versions are ignored. A first manual installation of 1.6.0 is required to enable updates from older versions.
